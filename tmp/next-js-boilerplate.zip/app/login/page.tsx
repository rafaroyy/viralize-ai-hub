"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { motion } from "framer-motion"
import { Loader2, Lock, Mail } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { authApi } from "@/lib/api-client"
import { authStore } from "@/lib/auth-store"

export default function LoginPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleLogin = async () => {
    setError("")
    setIsLoading(true)

    if (!email || !password) {
      setError("Por favor, preencha email e senha.")
      setIsLoading(false)
      return
    }

    try {
      const response = await authApi.login(email, password)

      // Verify we got a valid response with access_token
      if (!response || !response.access_token) {
        throw new Error("Resposta inválida do servidor")
      }

      authStore.setToken(response.access_token)
      authStore.setUserData({
        user_id: response.user_id,
        username: response.username,
      })

      toast({
        title: "Login realizado",
        description: `Bem-vindo, ${response.username}!`,
      })

      // Only redirect after successful login
      router.push("/editor")
    } catch (err: any) {
      const errorMessage =
        err?.status === 401 || err?.message?.includes("Não autorizado")
          ? "Email ou senha incorretos. Verifique suas credenciais."
          : err.message || "Erro ao conectar com o servidor. Tente novamente."

      setError(errorMessage)
      setIsLoading(false)

      // Prevent any navigation on error
      return
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 relative overflow-hidden">
      {/* ... existing background effects ... */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px]" />
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md mx-4 relative z-10"
      >
        <div className="glassmorphic-card p-8 shadow-2xl">
          {/* ... existing logo and title ... */}
          <div className="flex flex-col items-center mb-8">
            <Link href="/">
              <Image
                src="/viralize-ai-logo.png"
                alt="Viralize AI"
                width={80}
                height={80}
                className="mb-4 cursor-pointer"
              />
            </Link>
            <h1 className="text-3xl font-heading font-bold gradient-text text-center">Viralize AI</h1>
            <p className="text-sm text-muted-foreground mt-2 text-center">
              Entre com suas credenciais para acessar o editor
            </p>
          </div>

          <div className="space-y-4">
            {error && (
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/50 flex items-start gap-3">
                <svg
                  className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                <div className="flex-1">
                  <p className="text-sm font-medium text-destructive">{error}</p>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Email
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={isLoading}
                className="glassmorphic-inner-card"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    handleLogin()
                  }
                }}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="flex items-center gap-2">
                <Lock className="h-4 w-4" />
                Senha
              </Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={isLoading}
                className="glassmorphic-inner-card"
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault()
                    handleLogin()
                  }
                }}
              />
            </div>

            <Button
              type="button"
              onClick={(e) => {
                e.preventDefault()
                e.stopPropagation()
                handleLogin()
              }}
              className="w-full neumorphic-button-primary mt-6"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Entrando...
                </>
              ) : (
                "Entrar"
              )}
            </Button>
          </div>

          {/* ... existing back to home link ... */}
          <div className="mt-6 text-center">
            <Link href="/" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              ← Voltar para a home
            </Link>
          </div>
        </div>

        {/* ... existing security badge ... */}
        <div className="mt-4 text-center text-xs text-muted-foreground">
          <p>Acesso exclusivo para membros e convidados</p>
        </div>
      </motion.div>
    </div>
  )
}
