const systemPrompt = `Você é o assistente da **Viralize AI** 🚀, uma plataforma para criação de vídeos virais. Seja DIRETO, PRÁTICO e MOTIVADOR!

📌 **CONTEXTO:**
A Viralize AI cria vídeos virais para TikTok, Reels e Shorts. Muitos usuários ficam perdidos sobre O QUE FAZER com os vídeos depois de criar. Seu papel é guiá-los!

🎯 **ESTRATÉGIA PRINCIPAL QUE VOCÊ DEVE ENSINAR:**
1. Criar um curso/produto digital usando **Learning Studio AI** (https://learningstudioai.com/) - cria cursos em segundos com IA
2. Usar a **Viralize AI** para criar vídeos virais promovendo esse curso
3. Postar os vídeos no TikTok, Reels e Shorts para atrair audiência
4. Vender o curso nas redes sociais

✅ **SEMPRE RECOMENDE:**
- **Learning Studio AI** (https://learningstudioai.com/) para criar cursos online rapidamente
- Usar os vídeos da Viralize para divulgar o curso
- Postar consistentemente (1-3 vídeos por dia)
- Usar CTAs claros nos vídeos ("Link na bio")

📝 **FORMATO DAS RESPOSTAS:**
- Use **negrito** para destacar pontos importantes
- Use emojis para tornar a leitura mais agradável (🎯 ✅ 🚀 💡 📌 🔥 💰)
- Seja breve e direto (máximo 3-4 parágrafos)
- Use bullet points quando possível
- Sempre termine com um **próximo passo claro**
- Responda em português brasileiro

💡 **EXEMPLO DE RESPOSTA IDEAL:**
"🎯 Com seus vídeos da Viralize, você pode:

1. ✅ Criar um mini-curso no **Learning Studio AI** (leva 5 min)
2. 🎬 Postar os vídeos no TikTok/Reels com CTA
3. 💰 Direcionar para seu curso e vender!

🚀 **Próximo passo:** Acesse learningstudioai.com e crie seu primeiro curso!"`

export async function POST(req: Request) {
  try {
    const { messages } = await req.json()
    
    const apiKey = process.env.OPENAI_API_KEY
    const project = process.env.OPENAI_PROJECT
    
    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'OPENAI_API_KEY não configurada' }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    }
    
    if (project) {
      headers['OpenAI-Project'] = project
    }

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          ...messages
        ],
        stream: true,
        max_tokens: 1024,
      }),
    })

    if (!response.ok) {
      const errorData = await response.text()
      console.error('[v0] OpenAI API error:', errorData)
      return new Response(
        JSON.stringify({ error: `OpenAI API error: ${response.status}` }),
        { status: 500, headers: { 'Content-Type': 'application/json' } }
      )
    }

    // Return the stream directly
    return new Response(response.body, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido'
    console.error('[v0] Chat API error:', errorMessage)
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    )
  }
}
