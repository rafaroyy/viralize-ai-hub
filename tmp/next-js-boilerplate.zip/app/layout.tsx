import type React from "react"
import type { Metadata } from "next"
import { Inter, Montserrat } from 'next/font/google'

import { cn } from "@/lib/utils"
import { ThemeProvider } from "@/components/theme-provider"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { PageTransition } from "@/components/page-transition"

import "@/app/globals.css"
import { Suspense } from "react"

const fontSans = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  weight: ["300", "400", "500", "600"],
})

const fontHeading = Montserrat({
  subsets: ["latin"],
  variable: "--font-heading",
  weight: ["600", "700"],
})

export const metadata: Metadata = {
  title: "Viralize AI - O Cérebro Por Trás Dos Vídeos Que Viralizam",
  description: "A IA que carrega os frameworks responsáveis por +500 milhões de impressões orgânicas no TikTok e Instagram. Crie vídeos virais com frameworks reais de venda.",
  keywords: ["AI", "viral", "video", "tiktok", "instagram", "frameworks", "criação de conteúdo"],
    generator: 'v0.app'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={cn(
          "min-h-screen bg-background font-sans antialiased font-light",
          fontSans.variable,
          fontHeading.variable,
        )}
      >
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          <div className="relative flex min-h-screen flex-col">
            <Suspense>
              <PageTransition>
                <div className="flex-1">{children}</div>
              </PageTransition>
            </Suspense>
          </div>
        </ThemeProvider>
      </body>
    </html>
  )
}
