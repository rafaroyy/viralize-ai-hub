"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"

import { authApi } from "@/lib/api-client"
import { authStore } from "@/lib/auth-store"
import { PremiumEditor } from "@/components/video-editor/premium-editor"
import { ChatWidget } from "@/components/chat/chat-widget"

export default function EditorPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [username, setUsername] = useState("")

  useEffect(() => {
    const checkAuth = async () => {
      if (!authStore.isAuthenticated()) {
        router.push("/login")
        return
      }

      try {
        const userData = await authApi.me()
        setUsername(userData.username)
        authStore.setUserData(userData)
      } catch (error) {
        router.push("/login")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuth()
  }, [router])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <>
      <PremiumEditor />
      <ChatWidget />
    </>
  )
}
