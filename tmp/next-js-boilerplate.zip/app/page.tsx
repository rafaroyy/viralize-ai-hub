import { HeroSection } from "@/components/sections/hero-section"
import { FeaturesSection } from "@/components/sections/features-section"
import { ComponentLibraryShowcase } from "@/components/sections/component-library-showcase"
import { TestimonialsSection } from "@/components/sections/testimonials-section"
import { BlogSection } from "@/components/sections/blog-section"
import { FaqSection } from "@/components/sections/faq-section"
import { CtaSection } from "@/components/sections/cta-section"
import { MouseGlow } from "@/components/ui-library/effects/mouse-glow"
import { WorkflowSection } from "@/components/sections/workflow-section"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"

export default function HomePage() {
  return (
    <>
      <SiteHeader />
      <main className="flex flex-col items-center relative">
        <MouseGlow
          color="rgba(168, 85, 247, 0.12)"
          size={600}
          blur={150}
          opacity={0.6}
          followSpeed={0.05}
          pulseEffect={true}
          pulseSpeed={4}
          pulseScale={1.05}
        />

        <HeroSection />
        <FeaturesSection />
        <WorkflowSection />
        <ComponentLibraryShowcase />
        <TestimonialsSection />
        <BlogSection />
        <FaqSection />
        <CtaSection />
      </main>
      <SiteFooter />
    </>
  )
}
