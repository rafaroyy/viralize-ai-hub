const API_BASE_URL = "https://api.viralizeia.com"

const CONFIG = {
  API_BASE_URL,
}

// Diagnostic log to confirm the URL being used
if (typeof window !== "undefined") {
  console.log("[v0] API_BASE_URL configured:", API_BASE_URL)
}

export default CONFIG
export { API_BASE_URL }
