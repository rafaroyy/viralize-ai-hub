import { API_BASE_URL } from "./config"
import type { LoginResponse, UserData, VideoRenderResponse, VideoStatusResponse, VideoListItem } from "./types"

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public data?: any,
  ) {
    super(message)
    this.name = "ApiError"
  }
}

class ApiClient {
  private baseUrl: string
  private tokenKey = "viralizeai.token"
  private userKey = "viralizeai.user"

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl
    console.log("[v0] ApiClient initialized:", baseUrl)
  }

  private getToken(): string | null {
    if (typeof window === "undefined") return null
    return localStorage.getItem(this.tokenKey)
  }

  private async handleResponse<T>(response: Response): Promise<T> {
    // Handle 401 - redirect to login
    if (response.status === 401) {
      if (typeof window !== "undefined") {
        localStorage.removeItem(this.tokenKey)
        localStorage.removeItem(this.userKey)
        window.location.href = "/login"
      }
      throw new ApiError(401, "Não autorizado. Faça login novamente.")
    }

    if (!response.ok) {
      let errorMessage = `Erro ${response.status}`
      try {
        const errorData = await response.json()
        errorMessage = errorData.detail || errorData.message || errorMessage
        console.error("[v0] API Error:", errorData)
        throw new ApiError(response.status, errorMessage, errorData)
      } catch (e) {
        if (e instanceof ApiError) throw e
        throw new ApiError(response.status, errorMessage)
      }
    }

    // Handle empty responses (204, DELETE, etc)
    if (response.status === 204 || response.headers.get("content-length") === "0") {
      return null as T
    }

    const contentType = response.headers.get("content-type")
    if (!contentType || !contentType.includes("application/json")) {
      return null as T
    }

    return response.json()
  }

  async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken()
    const headers: HeadersInit = {
      ...options.headers,
    }

    // Set Content-Type for JSON (not for FormData)
    if (options.body && !(options.body instanceof FormData)) {
      headers["Content-Type"] = "application/json"
    }

    // Add Authorization header
    if (token) {
      headers["Authorization"] = `Bearer ${token}`
    }

    const url = `${this.baseUrl}${endpoint}`

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      })

      return this.handleResponse<T>(response)
    } catch (error) {
      console.error("[v0] API Request failed:", error)
      if (error instanceof ApiError) throw error
      if (error instanceof TypeError && error.message === "Failed to fetch") {
        throw new ApiError(0, `Não foi possível conectar à API. Verifique sua conexão e tente novamente.`)
      }
      throw new ApiError(0, "Erro desconhecido ao fazer requisição")
    }
  }

  async get<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: "GET" })
  }

  async post<T>(endpoint: string, data?: any): Promise<T> {
    return this.request<T>(endpoint, {
      method: "POST",
      body: data instanceof FormData ? data : JSON.stringify(data),
    })
  }

  async delete<T>(endpoint: string): Promise<T> {
    return this.request<T>(endpoint, { method: "DELETE" })
  }

  async downloadBlob(endpoint: string): Promise<Blob> {
    const token = this.getToken()
    const headers: HeadersInit = {}

    if (token) {
      headers["Authorization"] = `Bearer ${token}`
    }

    const url = `${this.baseUrl}${endpoint}`

    console.log("[v0] Downloading from:", url)

    try {
      const response = await fetch(url, { headers })

      if (response.status === 401) {
        if (typeof window !== "undefined") {
          localStorage.removeItem(this.tokenKey)
          localStorage.removeItem(this.userKey)
          window.location.href = "/login"
        }
        throw new ApiError(401, "Não autorizado")
      }

      if (!response.ok) {
        let errorMessage = `Erro ${response.status}`
        try {
          const errorData = await response.json()
          errorMessage = errorData.detail || errorData.message || errorMessage
        } catch {
          errorMessage = `Erro ${response.status}: ${response.statusText || "Falha ao baixar vídeo"}`
        }
        console.error("[v0] Download error:", errorMessage)
        throw new ApiError(response.status, errorMessage)
      }

      const blob = await response.blob()
      console.log("[v0] Download successful, blob size:", blob.size)
      return blob
    } catch (error) {
      console.error("[v0] Download failed:", error)
      if (error instanceof ApiError) throw error
      throw new ApiError(0, "Falha ao conectar com o servidor para download")
    }
  }
}

const apiClient = new ApiClient(API_BASE_URL)

// Auth API
export const authApi = {
  async login(email: string, password: string): Promise<LoginResponse> {
    return apiClient.post<LoginResponse>("/auth/login", { email, password })
  },

  async me(): Promise<UserData> {
    return apiClient.get<UserData>("/auth/me")
  },

  logout() {
    if (typeof window === "undefined") return
    localStorage.removeItem("viralizeai.token")
    localStorage.removeItem("viralizeai.user")
  },
}

// Video API
export const videoApi = {
  async render(formData: FormData): Promise<VideoRenderResponse> {
    return apiClient.post<VideoRenderResponse>("/videos/render", formData)
  },

  async getStatus(jobId: string): Promise<VideoStatusResponse> {
    return apiClient.get<VideoStatusResponse>(`/videos/status/${jobId}`)
  },

  async download(jobId: string): Promise<Blob> {
    return apiClient.downloadBlob(`/videos/download/${jobId}`)
  },

  async list(skip = 0, limit = 100): Promise<VideoListItem[]> {
    const response = await apiClient.get<any>(`/videos/list?skip=${skip}&limit=${limit}`)

    // Handle different response formats
    if (Array.isArray(response)) {
      return response
    }
    if (response && typeof response === "object") {
      if ("videos" in response) return response.videos
      if ("data" in response) return response.data
      if ("items" in response) return response.items
      return [response]
    }
    return []
  },

  async delete(jobId: string): Promise<void> {
    return apiClient.delete<void>(`/videos/${jobId}`)
  },
}
