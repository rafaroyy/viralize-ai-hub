export interface VideoPayload {
  objetivo_video: string
  tema: string
  nicho: string
  palavra_chave_global: string
  idioma: string
  duracao: number
  cenas: number
  tipo_roteiro: string
  roteiro_sugerido_usuario: string
  bullet_points_roteiro: string[]
  usar_legenda_e_fala: boolean
  metadata: {
    duration: number
    cenas: number
    aspect_ratio: string
    usar_legenda_e_fala: boolean
  }
}

export interface VideoJob {
  job_id: string
  status: string
  progress: number
  message: string
  error?: string
  created_at: string
  updated_at: string
}

export type VideoStatus = "queued" | "script" | "media" | "render" | "finalize" | "done" | "error"

export const VIDEO_STATUS_LABELS: Record<VideoStatus, string> = {
  queued: "Na fila",
  script: "Gerando roteiro",
  media: "Selecionando mídias",
  render: "Renderizando",
  finalize: "Finalizando",
  done: "Concluído",
  error: "Erro",
}

export const TIPO_ROTEIRO_OPTIONS = [
  { value: "educativo-com-prova-social", label: "Educativo com Prova Social" },
  { value: "story-telling", label: "Story Telling" },
  { value: "provocativo", label: "Provocativo" },
  { value: "tutorial", label: "Tutorial" },
  { value: "listicle", label: "Listicle (Lista)" },
]

export const IDIOMA_OPTIONS = [
  { value: "pt-BR", label: "Português (BR)" },
  { value: "en-US", label: "English (US)" },
  { value: "es-ES", label: "Español" },
]
