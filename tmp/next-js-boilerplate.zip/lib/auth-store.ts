import type { UserData } from "./types"

const TOKEN_KEY = "viralizeai.token"
const USER_DATA_KEY = "viralizeai.user"

export const authStore = {
  setToken(token: string) {
    if (typeof window === "undefined") return
    localStorage.setItem(TOKEN_KEY, token)
  },

  getToken(): string | null {
    if (typeof window === "undefined") return null
    return localStorage.getItem(TOKEN_KEY)
  },

  setUserData(userData: UserData) {
    if (typeof window === "undefined") return
    localStorage.setItem(USER_DATA_KEY, JSON.stringify(userData))
  },

  getUserData(): UserData | null {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem(USER_DATA_KEY)
    return data ? JSON.parse(data) : null
  },

  clear() {
    if (typeof window === "undefined") return
    localStorage.removeItem(TOKEN_KEY)
    localStorage.removeItem(USER_DATA_KEY)
  },

  isAuthenticated(): boolean {
    if (typeof window === "undefined") return false
    return !!localStorage.getItem(TOKEN_KEY)
  },
}
