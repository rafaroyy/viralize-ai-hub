"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { LogOut } from "lucide-react"

import { Button } from "@/components/ui/button"
import { authApi } from "@/lib/api-client"
import { EditorContent } from "./editor-content"
import { VideoHistory } from "./video-history"

interface VideoEditorProps {
  username: string
}

export function VideoEditor({ username }: VideoEditorProps) {
  const router = useRouter()
  const [showHistory, setShowHistory] = useState(false)

  const handleLogout = () => {
    authApi.logout()
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Topbar */}
      <header className="h-16 border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container h-full px-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Image src="/viralize-ai-logo.png" alt="Viralize AI" width={40} height={40} className="rounded" />
            <h1 className="text-xl font-heading font-semibold gradient-text">Viralize AI Editor</h1>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="outline" size="sm" onClick={() => setShowHistory(!showHistory)}>
              {showHistory ? "Editor" : "Histórico"}
            </Button>
            <div className="text-sm">
              Olá, <span className="font-semibold text-primary">{username}</span>
            </div>
            <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-2">
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 min-h-0">{showHistory ? <VideoHistory /> : <EditorContent />}</div>
    </div>
  )
}
