"use client"

import { useEffect, useState } from "react"
import { Loader2, Download, Trash2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"
import { videoApi } from "@/lib/api-client"
import { VIDEO_STATUS_LABELS } from "@/lib/video-types"

interface VideoItem {
  job_id: string
  status: string
  progress?: number
  video_title?: string
  created_at: string
  completed_at?: string
  updated_at?: string
  payload?: any
}

export function VideoHistory() {
  const { toast } = useToast()
  const [videos, setVideos] = useState<VideoItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadVideos()
  }, [])

  const loadVideos = async () => {
    setIsLoading(true)
    try {
      const data = await videoApi.list(100)
      console.log("[v0] Raw API response:", data)

      let videoArray: VideoItem[] = []

      // Handle API response format: { jobs: [...], total: 9, skip: 100, limit: 100 }
      if (data && typeof data === "object" && !Array.isArray(data)) {
        if ("jobs" in data && Array.isArray(data.jobs)) {
          videoArray = data.jobs
        } else if ("videos" in data && Array.isArray((data as any).videos)) {
          videoArray = (data as any).videos
        } else if ("data" in data && Array.isArray((data as any).data)) {
          videoArray = (data as any).data
        } else if ("items" in data && Array.isArray((data as any).items)) {
          videoArray = (data as any).items
        }
      } else if (Array.isArray(data)) {
        videoArray = data
      }

      console.log("[v0] Extracted video array:", videoArray)
      console.log("[v0] Array length:", videoArray.length)
      setVideos(videoArray)
    } catch (error: any) {
      console.error("[v0] Failed to load videos:", error)
      toast({
        title: "Erro ao carregar histórico",
        description: error.message || "Erro desconhecido",
        variant: "destructive",
      })
      setVideos([])
    } finally {
      setIsLoading(false)
    }
  }

  const handleDownload = async (jobId: string) => {
    try {
      const blob = await videoApi.download(jobId)
      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `viralize-${jobId}.mp4`
      link.click()
      URL.revokeObjectURL(url)
    } catch (error: any) {
      toast({
        title: "Erro ao baixar",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleDelete = async (jobId: string) => {
    try {
      await videoApi.delete(jobId)
      setVideos((prev) => prev.filter((v) => v.job_id !== jobId))
      toast({
        title: "Vídeo excluído",
        description: "O vídeo foi removido do histórico.",
      })
    } catch (error: any) {
      toast({
        title: "Erro ao excluir",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="container p-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-heading font-bold gradient-text">Histórico de Vídeos</h2>
          <p className="text-muted-foreground mt-1">Gerencie seus vídeos criados</p>
        </div>

        {videos.length === 0 ? (
          <Card className="glassmorphic-card">
            <CardContent className="flex items-center justify-center py-12">
              <p className="text-muted-foreground">Nenhum vídeo encontrado</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {Array.isArray(videos) &&
              videos.map((video) => (
                <Card key={video.job_id} className="glassmorphic-card">
                  <CardHeader>
                    <CardTitle className="text-base">
                      {video.video_title || video.payload?.objetivo_video || `Vídeo ${video.job_id.slice(0, 8)}`}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="text-sm space-y-1">
                      <div>
                        <span className="text-muted-foreground">Status:</span>{" "}
                        <span
                          className={
                            video.status === "completed" || video.status === "done"
                              ? "text-green-500"
                              : video.status === "error" || video.status === "failed"
                                ? "text-destructive"
                                : "text-yellow-500"
                          }
                        >
                          {VIDEO_STATUS_LABELS[video.status as keyof typeof VIDEO_STATUS_LABELS] || video.status}
                        </span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Criado:</span>{" "}
                        {new Date(video.created_at).toLocaleString("pt-BR")}
                      </div>
                      {video.progress !== undefined && video.status !== "completed" && video.status !== "done" && (
                        <div>
                          <span className="text-muted-foreground">Progresso:</span> {video.progress}%
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {(video.status === "done" || video.status === "completed") && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownload(video.job_id)}
                          className="flex-1"
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Baixar
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleDelete(video.job_id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        )}
      </div>
    </div>
  )
}
