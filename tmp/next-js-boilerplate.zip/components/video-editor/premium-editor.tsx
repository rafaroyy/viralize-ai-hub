"use client"

import type React from "react"
import { useState, useRef, useCallback, useEffect } from "react"
import { Download, UploadIcon, VideoIcon, Wand2, Loader2, X, RefreshCw, Search, Play, AlertCircle } from "lucide-react"
import cn from "classnames"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { videoApi } from "@/lib/api-client"
import type { VideoPayload, VideoJob } from "@/lib/types"
import { VIDEO_STATUS_LABELS } from "@/lib/types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import type { VideoType } from "@/lib/types"
import { Slider } from "@/components/ui/slider"

export function PremiumEditor() {
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const pollingRef = useRef<NodeJS.Timeout | null>(null)

  const [viewState, setViewState] = useState<"config" | "processing" | "preview">("config")
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentJob, setCurrentJob] = useState<VideoJob | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)

  // Form state
  const [objetivo, setObjetivo] = useState("")
  const [tema, setTema] = useState("")
  const [nicho, setNicho] = useState("")
  const [palavraChave, setPalavraChave] = useState("")
  const [idioma, setIdioma] = useState("pt-BR")
  const [duracao, setDuracao] = useState(30)
  const [cenas, setCenas] = useState(3)
  const [tipoRoteiro, setTipoRoteiro] = useState("educativo-com-prova-social")
  const [roteiroSugerido, setRoteiroSugerido] = useState("")
  const [bulletPoints, setBulletPoints] = useState<string[]>([])
  const [usarLegenda, setUsarLegenda] = useState(true)
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])
  const [aspectRatio, setAspectRatio] = useState("9:16")

  // History state
  const [videos, setVideos] = useState<VideoType[]>([])
  const [isLoadingHistory, setIsLoadingHistory] = useState(false)
  const [searchHistory, setSearchHistory] = useState("")
  const [previewVideo, setPreviewVideo] = useState<{ id: string; url: string } | null>(null)
  const [failedVideos, setFailedVideos] = useState<Set<string>>(new Set())
  const [videoThumbnails, setVideoThumbnails] = useState<Record<string, string>>({})

  const loadHistory = async () => {
    setIsLoadingHistory(true)
    try {
      const data = await videoApi.list()
      console.log("[v0] loadHistory - Raw API response:", data)

      let videoArray: VideoType[] = []

      if (Array.isArray(data)) {
        if (data.length > 0 && data[0]?.jobs && Array.isArray(data[0].jobs)) {
          videoArray = data[0].jobs
        } else {
          videoArray = data
        }
      } else if (data && typeof data === "object" && "jobs" in data && Array.isArray(data.jobs)) {
        videoArray = data.jobs
      }

      console.log("[v0] loadHistory - Final extracted array:", videoArray.length, "videos")
      if (videoArray.length > 0) {
        console.log("[v0] loadHistory - First 3 videos:", videoArray.slice(0, 3))
      }

      setVideos(videoArray)
      preloadThumbnails(videoArray)
    } catch (error: any) {
      console.error("[v0] loadHistory error:", error)
      toast({
        title: "Erro ao carregar histórico",
        description: error.message || "Não foi possível carregar seus vídeos.",
        variant: "destructive",
      })
    } finally {
      setIsLoadingHistory(false)
    }
  }

  const startPolling = useCallback(
    (jobId: string) => {
      if (pollingRef.current) clearInterval(pollingRef.current)

      pollingRef.current = setInterval(async () => {
        try {
          const status = await videoApi.getStatus(jobId)
          setCurrentJob(status)

          if (status.status === "done" || status.status === "completed" || status.status === "success") {
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            try {
              const blob = await videoApi.download(jobId)
              const url = URL.createObjectURL(blob)
              setVideoUrl(url)
              setViewState("preview")

              toast({
                title: "Vídeo pronto!",
                description: "Seu vídeo foi gerado com sucesso.",
              })

              loadHistory()
            } catch (error: any) {
              toast({
                title: "Erro ao carregar preview",
                description: error.message,
                variant: "destructive",
              })
            }

            setIsGenerating(false)
          } else if (status.status === "error" || status.status === "failed") {
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            toast({
              title: "Erro na geração",
              description: status.error || "Ocorreu um erro ao gerar o vídeo.",
              variant: "destructive",
            })

            setIsGenerating(false)
            setViewState("config")
          }
        } catch (error: any) {
          if (pollingRef.current) {
            clearInterval(pollingRef.current)
            pollingRef.current = null
          }
          setIsGenerating(false)
          setViewState("config")
        }
      }, 2500)
    },
    [toast],
  )

  const handleGenerate = async () => {
    if (!objetivo || !tema || !nicho || !palavraChave) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha objetivo, tema, nicho e palavra-chave.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setVideoUrl(null)
    setCurrentJob(null)
    setViewState("processing")

    try {
      const payload: VideoPayload = {
        objetivo_video: objetivo,
        tema,
        nicho,
        palavra_chave_global: palavraChave,
        idioma,
        duracao,
        cenas,
        tipo_roteiro: tipoRoteiro,
        roteiro_sugerido_usuario: roteiroSugerido,
        bullet_points_roteiro: bulletPoints,
        usar_legenda_e_fala: usarLegenda,
        metadata: {
          duration: duracao,
          cenas,
          aspect_ratio: aspectRatio,
          usar_legenda_e_fala: usarLegenda,
        },
      }

      const formData = new FormData()
      formData.append("payload", JSON.stringify(payload))

      uploadedFiles.forEach((file) => {
        formData.append("files", file)
      })

      const response = await videoApi.render(formData)

      setCurrentJob({
        job_id: response.job_id,
        status: response.status,
        progress: 0,
        message: response.message || "Processando...",
        created_at: response.created_at,
        updated_at: response.created_at,
      })

      toast({
        title: "Vídeo em geração",
        description: "Acompanhe o progresso.",
      })

      startPolling(response.job_id)
    } catch (error: any) {
      toast({
        title: "Erro ao gerar vídeo",
        description: error.message,
        variant: "destructive",
      })
      setIsGenerating(false)
      setViewState("config")
    }
  }

  const handleDownload = () => {
    if (!videoUrl || !currentJob) return

    const link = document.createElement("a")
    link.href = videoUrl
    link.download = `viralize-${currentJob.job_id}.mp4`
    link.click()
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)
      setUploadedFiles((prev) => [...prev, ...files])
    }
  }

  const removeFile = (indexToRemove: number) => {
    setUploadedFiles((prevFiles) => prevFiles.filter((_, index) => index !== indexToRemove))
  }

  const handleGenerateAnother = () => {
    setViewState("config")
    setVideoUrl(null)
    setCurrentJob(null)
    setIsGenerating(false)
  }

  const getStatusBadge = () => {
    if (!currentJob) return null

    const statusColors: Record<string, string> = {
      queued: "bg-blue-500",
      script: "bg-purple-500",
      media: "bg-indigo-500",
      render: "bg-orange-500",
      finalize: "bg-amber-500",
      done: "bg-green-500",
      completed: "bg-green-500",
      error: "bg-red-500",
      failed: "bg-red-500",
    }

    return (
      <Badge className={`${statusColors[currentJob.status] || "bg-gray-500"} text-white border-none`}>
        {VIDEO_STATUS_LABELS[currentJob.status as keyof typeof VIDEO_STATUS_LABELS] || currentJob.status}
      </Badge>
    )
  }

  const getProgressSteps = () => {
    if (!currentJob) return []

    const steps = [
      { key: "queued", label: "Na fila", icon: "⏳" },
      { key: "script", label: "Gerando roteiro", icon: "📝" },
      { key: "media", label: "Selecionando mídia", icon: "🎬" },
      { key: "render", label: "Renderizando", icon: "⚡" },
      { key: "finalize", label: "Finalizando", icon: "✨" },
    ]

    const currentIndex = steps.findIndex((s) => s.key === currentJob.status)
    return steps.map((step, index) => ({
      ...step,
      active: index === currentIndex,
      completed: index < currentIndex,
    }))
  }

  const handleHistoryVideoClick = async (video: any) => {
    if (video.status !== "done" && video.status !== "completed") return

    try {
      const blob = await videoApi.download(video.job_id)
      const url = URL.createObjectURL(blob)
      setVideoUrl(url)
      setCurrentJob(video)
      setViewState("preview")
    } catch (error: any) {
      toast({
        title: "Erro ao carregar vídeo",
        description: error.message,
        variant: "destructive",
      })
    }
  }

  const handleDownloadHistoryVideo = async (videoId: string) => {
    console.log("[v0] handleDownloadHistoryVideo called with videoId:", videoId)

    if (!videoId) {
      toast({
        title: "Erro",
        description: "ID do vídeo não encontrado",
        variant: "destructive",
      })
      return
    }

    try {
      toast({
        title: "Baixando vídeo...",
        description: "O download vai começar em instantes",
      })

      console.log("[v0] Starting download for job_id:", videoId)
      const blob = await videoApi.download(videoId)
      console.log("[v0] Download complete, blob size:", blob.size)

      const url = URL.createObjectURL(blob)
      const link = document.createElement("a")
      link.href = url
      link.download = `viralize-${videoId}.mp4`
      link.click()
      URL.revokeObjectURL(url)

      toast({
        title: "Download iniciado",
        description: "Verifique seus downloads",
      })
    } catch (error: any) {
      console.error("[v0] Error downloading video:", error)
      console.error("[v0] Error details:", {
        message: error.message,
        status: error.status,
        name: error.name,
      })
      toast({
        title: "Erro ao baixar vídeo",
        description: error.message || "Erro desconhecido ao fazer download",
        variant: "destructive",
      })
    }
  }

  const handlePreviewHistoryVideo = async (videoId: string) => {
    try {
      console.log(`[v0] Loading preview for ${videoId}`)
      const blob = await videoApi.download(videoId)
      const url = URL.createObjectURL(blob)
      setPreviewVideo({ id: videoId, url })
    } catch (error: any) {
      console.error("[v0] Error loading preview:", error)
      toast({
        title: "Erro ao carregar preview",
        description: error.message || "Não foi possível carregar o vídeo.",
        variant: "destructive",
      })
    }
  }

  const handleClosePreview = () => {
    if (previewVideo?.url) {
      URL.revokeObjectURL(previewVideo.url)
    }
    setPreviewVideo(null)
  }

  const preloadThumbnails = async (videos: any[]) => {
    console.log("[v0] Preloading thumbnails for", videos.length, "videos")

    const completedVideos = videos.filter((v) => {
      const videoId = v.job_id
      const isReady = v.status === "completed" || v.status === "done" || v.status === "Ready"
      const alreadyFailed = failedVideos.has(videoId)
      return isReady && !alreadyFailed && !videoThumbnails[videoId]
    })

    // Process in batches of 3
    for (let i = 0; i < completedVideos.length; i += 3) {
      const batch = completedVideos.slice(i, i + 3)
      await Promise.all(
        batch.map(async (video) => {
          const videoId = video.job_id
          try {
            console.log("[v0] Preloading thumbnail for", videoId)
            const blob = await videoApi.download(videoId)
            const url = URL.createObjectURL(blob)
            setVideoThumbnails((prev) => ({ ...prev, [videoId]: url }))
            console.log("[v0] Thumbnail preloaded for", videoId)
          } catch (error: any) {
            console.log("[v0] Failed to preload thumbnail for", videoId)
            setFailedVideos((prev) => new Set(prev).add(videoId))
          }
        }),
      )
    }
  }

  const filteredVideos = Array.isArray(videos)
    ? videos.filter((v) => {
        if (!searchHistory) return true
        const title = v?.video_title || v?.titulo || v?.payload?.objetivo_video || "Vídeo sem título"
        return title.toLowerCase().includes(searchHistory.toLowerCase())
      })
    : []

  useEffect(() => {
    console.log("[v0] PremiumEditor mounted - loading history")
    loadHistory()
  }, [])

  return (
    <div className="min-h-screen bg-background">
      {/* Main Content */}
      <div className="container mx-auto px-3 sm:px-4 md:px-6 lg:px-8 py-4 sm:py-6 lg:py-8 max-w-[1600px]">
        {/* Page Title */}
        <div className="mb-6 sm:mb-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight transition-colors duration-300 hover:text-primary cursor-default">
              Criar Vídeo Viral
            </h1>
            <p className="text-sm sm:text-base text-muted-foreground mt-2">
              Configure seu video em minutos e obtenha milhares de visualizações!
            </p>
          </div>
          <Button
            size="lg"
            className="hidden lg:flex gap-2 font-semibold px-8 h-12 whitespace-nowrap"
            onClick={handleGenerate}
            disabled={isGenerating || !objetivo || !tema || !nicho || !palavraChave}
          >
            {isGenerating ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Gerando...
              </>
            ) : (
              <>
                <Wand2 className="h-5 w-5" />
                Gerar Vídeo
              </>
            )}
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 lg:gap-8">
          {/* Left Column - Form */}
          <div className="space-y-5 lg:space-y-6">
            {/* Form Cards */}
            <div className="space-y-5">
              <Card className="border-border/40 bg-card/80 backdrop-blur-sm shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="text-lg font-semibold flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-primary"></span>
                    Informações do Vídeo
                  </CardTitle>
                  <CardDescription className="text-sm text-muted-foreground">Preencha os campos abaixo para configurar seu video</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-5">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
                    <div className="space-y-2">
                      <Label htmlFor="objetivo" className="text-sm font-medium">
                        Objetivo *
                      </Label>
                      <Input
                        id="objetivo"
                        placeholder="Ex: Vender curso online"
                        value={objetivo}
                        onChange={(e) => setObjetivo(e.target.value)}
                        disabled={isGenerating}
                        className="h-11 md:h-10"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tema" className="text-sm font-medium">
                        Tema *
                      </Label>
                      <Input
                        id="tema"
                        placeholder="Ex: Produtividade"
                        value={tema}
                        onChange={(e) => setTema(e.target.value)}
                        disabled={isGenerating}
                        className="h-11 md:h-10"
                      />
                      {tema.trim() && (
                        <p className="text-xs text-primary font-medium flex items-center gap-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
                          <span className="inline-block w-1.5 h-1.5 bg-primary rounded-full"></span>
                          Tema preenchido! Busque inspiracao no TikTok abaixo
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nicho" className="text-sm font-medium">
                        Nicho *
                      </Label>
                      <Input
                        id="nicho"
                        placeholder="Ex: Empreendedorismo digital"
                        value={nicho}
                        onChange={(e) => setNicho(e.target.value)}
                        disabled={isGenerating}
                        className="h-11 md:h-10"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="palavra-chave" className="text-sm font-medium">
                        Palavra-chave *
                      </Label>
                      <Input
                        id="palavra-chave"
                        placeholder="Ex: productivity"
                        value={palavraChave}
                        onChange={(e) => setPalavraChave(e.target.value)}
                        disabled={isGenerating}
                        className="h-11 md:h-10"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button
                type="button"
                className="w-full h-16 gap-4 bg-black hover:bg-black/90 text-white rounded-xl shadow-lg transition-all"
                disabled={!tema.trim() && !palavraChave.trim()}
                onClick={() => {
                  const searchTerm = palavraChave.trim() || tema.trim()
                  const query = encodeURIComponent(searchTerm)
                  window.open(`https://www.tiktok.com/search?q=${query}`, '_blank')
                }}
              >
                <img 
                  src="/tiktok-icon.png" 
                  alt="TikTok" 
                  className="h-10 w-10 rounded-lg"
                />
                <span className="text-lg font-semibold">Buscar inspiração</span>
              </Button>

              <Card className="border-border/50">
                <CardHeader className="pb-3 sm:pb-4">
                  <CardTitle className="text-base md:text-lg font-semibold">Modo de Narração</CardTitle>
                  <CardDescription className="text-xs md:text-sm">Escolha o estilo do seu vídeo</CardDescription>
                </CardHeader>
                <CardContent>
                  <RadioGroup
                    value={usarLegenda ? "com-narracao" : "mudo"}
                    onValueChange={(v) => setUsarLegenda(v === "com-narracao")}
                  >
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-start space-x-3 p-5 rounded-xl border-2 border-border hover:border-primary/60 transition-all cursor-pointer">
                        <RadioGroupItem value="com-narracao" id="com-narracao" className="mt-0.5" />
                        <div className="flex-1">
                          <Label htmlFor="com-narracao" className="cursor-pointer font-semibold text-base">
                            Com narração + legenda
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1.5">IA narra e exibe legendas</p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-3 p-5 rounded-xl border-2 border-border hover:border-primary/60 transition-all cursor-pointer">
                        <RadioGroupItem value="mudo" id="mudo" className="mt-0.5" />
                        <div className="flex-1">
                          <Label htmlFor="mudo" className="cursor-pointer font-semibold text-base">
                            Mudo com texto central
                          </Label>
                          <p className="text-sm text-muted-foreground mt-1.5">Texto no centro sem áudio</p>
                        </div>
                      </div>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3 sm:pb-4">
                  <CardTitle className="text-base md:text-lg font-semibold">Roteiro</CardTitle>
                  <CardDescription className="text-xs md:text-sm">
                    Configure o tipo e estrutura do conteúdo
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="tipo-roteiro" className="text-sm font-medium">
                      Tipo de Roteiro
                    </Label>
                    <Select value={tipoRoteiro} onValueChange={setTipoRoteiro} disabled={isGenerating}>
                      <SelectTrigger id="tipo-roteiro" className="h-10">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="educativo-com-prova-social">Educativo com prova social</SelectItem>
                        <SelectItem value="cinematic-date">Cinemático com gancho</SelectItem>
                        <SelectItem value="storytelling">Storytelling</SelectItem>
                        <SelectItem value="tutorial">Tutorial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="roteiro-sugerido" className="text-sm font-medium">
                      Sugestão de Roteiro (Opcional)
                    </Label>
                    <Textarea
                      id="roteiro-sugerido"
                      placeholder="Explique a linha geral, ganchos, provas..."
                      rows={3}
                      value={roteiroSugerido}
                      onChange={(e) => setRoteiroSugerido(e.target.value)}
                      disabled={isGenerating}
                      className="resize-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bullet-points" className="text-sm font-medium">
                      Pontos Principais (Opcional)
                    </Label>
                    <Textarea
                      id="bullet-points"
                      placeholder="• Ponto 1: Introdução\n• Ponto 2: Desenvolvimento\n• Ponto 3: Call to action"
                      rows={4}
                      value={bulletPoints.join("\n")}
                      onChange={(e) => setBulletPoints(e.target.value.split("\n"))}
                      className="resize-none font-mono text-sm"
                      disabled={isGenerating}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3 sm:pb-4">
                  <CardTitle className="text-base md:text-lg font-semibold">Vídeos Personalizados (Opcional)</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div
                    className="border-2 border-dashed border-border/60 rounded-xl p-8 text-center cursor-pointer hover:border-primary/60 hover:bg-primary/5 transition-all"
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <UploadIcon className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
                    <p className="text-sm font-medium">Arraste ou clique para adicionar</p>
                    <p className="text-xs text-muted-foreground mt-1">MP4, MOV, AVI</p>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="video/mp4,video/quicktime,video/x-msvideo"
                      multiple
                      className="hidden"
                      onChange={handleFileSelect}
                    />
                  </div>

                  {uploadedFiles.length > 0 && (
                    <div className="space-y-2">
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg text-sm">
                          <VideoIcon className="h-4 w-4 text-primary flex-shrink-0" />
                          <span className="flex-1 truncate font-medium">{file.name}</span>
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            className="h-7 w-7"
                            onClick={() => removeFile(index)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border-border/50">
                <CardHeader className="pb-3 sm:pb-4">
                  <CardTitle className="text-base md:text-lg font-semibold">Configurações do Vídeo</CardTitle>
                  <CardDescription className="text-xs md:text-sm">
                    Defina idioma, duração e número de cenas
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 sm:space-y-5">
                  <div className="space-y-2">
                    <Label htmlFor="idioma" className="text-sm font-medium">
                      Idioma
                    </Label>
                    <div className="h-11 md:h-10 px-3 py-2 rounded-md border border-border bg-muted/30 flex items-center text-sm">
                      🇧🇷 Português (BR)
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="duracao" className="text-sm font-medium">
                        Duração do vídeo
                      </Label>
                      <span className="text-sm font-semibold text-primary">{duracao}s</span>
                    </div>
                    <Slider
                      id="duracao"
                      min={15}
                      max={60}
                      step={5}
                      value={[duracao]}
                      onValueChange={(value) => setDuracao(value[0])}
                      disabled={isGenerating}
                      className="w-full"
                    />
                    <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                      <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                      <p className="text-sm text-amber-600 dark:text-amber-500 font-medium">
                        Vídeos mais longos levam mais tempo para processar.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="cenas" className="text-sm font-medium">
                        Número de cenas
                      </Label>
                      <span className="text-sm font-semibold text-primary">{cenas}</span>
                    </div>
                    <Slider
                      id="cenas"
                      min={1}
                      max={10}
                      step={1}
                      value={[cenas]}
                      onValueChange={(value) => setCenas(value[0])}
                      disabled={isGenerating}
                      className="w-full"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Right Column - Preview (Sticky on desktop) */}
          <div className="lg:sticky lg:top-24 lg:self-start space-y-4 sm:space-y-6">
            <Card className="border-border/50">
              <CardHeader className="pb-3 sm:pb-4">
                <CardTitle className="text-base md:text-lg font-semibold">Preview</CardTitle>
              </CardHeader>
              <CardContent>
                {viewState === "config" && !videoUrl && (
                  <div className="aspect-[9/16] bg-muted/30 rounded-xl flex flex-col items-center justify-center text-center p-6 sm:p-8">
                    <div className="h-12 w-12 md:h-16 md:w-16 rounded-full bg-primary/10 flex items-center justify-center mb-3 md:mb-4">
                      <VideoIcon className="h-6 w-6 md:h-8 md:w-8 text-primary" />
                    </div>
                    <p className="text-xs md:text-sm text-muted-foreground">Configure e gere seu vídeo</p>
                  </div>
                )}

                {viewState === "processing" && currentJob && (
                  <div className="space-y-5">
                    <div className="aspect-[9/16] bg-muted/30 rounded-xl flex flex-col items-center justify-center p-6">
                      <Loader2 className="h-14 w-14 animate-spin text-primary mb-4" />
                      <p className="text-base font-semibold">Gerando vídeo...</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {VIDEO_STATUS_LABELS[currentJob.status as keyof typeof VIDEO_STATUS_LABELS] ||
                          currentJob.status}
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Progresso</span>
                        <span className="font-bold">{currentJob.progress || 0}%</span>
                      </div>
                      <Progress value={currentJob.progress || 0} className="h-2" />
                    </div>
                  </div>
                )}

                {viewState === "preview" && videoUrl && currentJob && (
                  <div className="space-y-4">
                    <div className="aspect-[9/16] bg-background rounded-xl overflow-hidden">
                      <video src={videoUrl} className="w-full h-full object-cover" controls />
                    </div>

                    <div className="space-y-2">
                      <Button onClick={handleDownload} className="w-full gap-2 h-11 font-semibold">
                        <Download className="h-5 w-5" />
                        Baixar Vídeo
                      </Button>
                      <Button
                        onClick={handleGenerateAnother}
                        variant="outline"
                        className="w-full gap-2 h-11 bg-transparent"
                      >
                        <RefreshCw className="h-4 w-4" />
                        Gerar Outro
                      </Button>
                    </div>

                    <Separator />

                    <div className="space-y-3 text-sm">
                      <h4 className="font-semibold">Detalhes</h4>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Tema:</span>
                          <span className="font-medium">{tema}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Duração:</span>
                          <span className="font-medium">{duracao}s</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">Cenas:</span>
                          <span className="font-medium">{cenas}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* My Videos Section - Better top margin */}
        <div className="mt-8 sm:mt-10 lg:mt-12">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 sm:mb-6">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight">Meus vídeos</h2>
              <p className="text-sm md:text-base text-muted-foreground mt-1">Vídeos gerados recentemente</p>
            </div>

            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar..."
                value={searchHistory}
                onChange={(e) => setSearchHistory(e.target.value)}
                className="pl-10 w-full sm:w-72 h-11 md:h-10"
              />
            </div>
          </div>

          {isLoadingHistory ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="h-10 w-10 animate-spin text-primary" />
            </div>
          ) : filteredVideos.length === 0 ? (
            <Card className="border-border/50">
              <CardContent className="flex items-center justify-center py-16">
                <p className="text-muted-foreground">Nenhum vídeo encontrado</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2 sm:gap-3">
              {filteredVideos.map((video: any) => {
                const videoId = video?.job_id || video?.id || ""
                const title = video?.video_title || video?.titulo || video?.title || "Vídeo sem título"
                const status = video?.status || "processing"
                const isReady = status === "completed" || status === "done" || status === "Ready"
                const hasFailed = failedVideos.has(videoId)
                const thumbnailUrl = videoThumbnails[videoId]

                return (
                  <div key={videoId} className="flex flex-col">
                    <button
                      onClick={() => !hasFailed && isReady && handlePreviewHistoryVideo(videoId)}
                      disabled={!isReady || hasFailed}
                      className="group relative aspect-[9/16] bg-gradient-to-br from-muted to-muted/50 rounded-md overflow-hidden border border-border hover:border-primary/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {isReady && !hasFailed ? (
                        <>
                          {thumbnailUrl ? (
                            <video
                              src={thumbnailUrl}
                              className="absolute inset-0 w-full h-full object-cover"
                              preload="metadata"
                            />
                          ) : (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                            </div>
                          )}

                          <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity">
                            <div className="bg-primary rounded-full p-1.5 md:p-2 transform group-hover:scale-110 transition-transform">
                              <Play className="h-5 w-5 md:h-6 md:w-6 text-primary-foreground fill-current" />
                            </div>
                          </div>
                        </>
                      ) : hasFailed ? (
                        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-gradient-to-br from-destructive/10 to-destructive/5">
                          <div className="text-destructive">
                            <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                              />
                            </svg>
                          </div>
                          <span className="text-[9px] text-destructive/80 font-medium">Não disponível</span>
                        </div>
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-muted to-muted/50">
                          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                        </div>
                      )}

                      <div className="absolute top-1 right-1">
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full px-1.5 py-0.5 text-[8px] md:text-[9px] font-medium",
                            isReady && !hasFailed
                              ? "bg-green-500/90 text-white"
                              : hasFailed
                                ? "bg-destructive/90 text-white"
                                : "bg-yellow-500/90 text-white",
                          )}
                        >
                          {hasFailed ? "Erro" : isReady ? "Pronto" : "Processando"}
                        </span>
                      </div>

                      {isReady && !hasFailed && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            handleDownloadHistoryVideo(videoId)
                          }}
                          className="absolute bottom-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity bg-card/90 hover:bg-card border border-border rounded p-1.5 md:p-1"
                          title="Baixar vídeo"
                        >
                          <Download className="h-3.5 w-3.5 md:h-3 md:w-3" />
                        </button>
                      )}
                    </button>

                    <p className="mt-1 text-[9px] md:text-[10px] text-muted-foreground line-clamp-2 leading-tight">
                      {title}
                    </p>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      {/* Mobile CTA - Better padding */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 p-3 sm:p-4 bg-background/95 backdrop-blur-md border-t border-border/50 shadow-2xl">
        <Button
          size="lg"
          className="w-full gap-2 font-semibold h-14 sm:h-12 text-base"
          onClick={handleGenerate}
          disabled={isGenerating || !objetivo || !tema || !nicho || !palavraChave}
        >
          {isGenerating ? (
            <>
              <Loader2 className="h-5 w-5 animate-spin" />
              Gerando...
            </>
          ) : (
            <>
              <Wand2 className="h-5 w-5" />
              Gerar Vídeo
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

export default PremiumEditor
