"use client"

import type React from "react"

import { useState, useCallback, useRef, useEffect } from "react"
import { Loader2, Play, Download, Upload, Plus, X, GripVertical } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { videoApi } from "@/lib/api-client"
import type { VideoPayload, VideoJob } from "@/lib/video-types"
import { TIPO_ROTEIRO_OPTIONS, IDIOMA_OPTIONS, VIDEO_STATUS_LABELS } from "@/lib/video-types"

export function EditorContent() {
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentJob, setCurrentJob] = useState<VideoJob | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const pollingRef = useRef<NodeJS.Timeout | null>(null)
  const abortControllerRef = useRef<AbortController | null>(null)

  // Form state
  const [objetivo, setObjetivo] = useState("")
  const [tema, setTema] = useState("")
  const [nicho, setNicho] = useState("")
  const [palavraChave, setPalavraChave] = useState("")
  const [idioma, setIdioma] = useState("pt-BR")
  const [duracao, setDuracao] = useState(30)
  const [cenas, setCenas] = useState(3)
  const [tipoRoteiro, setTipoRoteiro] = useState("educativo-com-prova-social")
  const [roteiroSugerido, setRoteiroSugerido] = useState("")
  const [bulletPoints, setBulletPoints] = useState<string[]>([""])
  const [usarLegenda, setUsarLegenda] = useState(true)
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])

  const fileInputRef = useRef<HTMLInputElement>(null)

  // Cleanup polling on unmount
  useEffect(() => {
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort()
      }
    }
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)
      setUploadedFiles((prev) => [...prev, ...files])
    }
  }

  const removeFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const addBulletPoint = () => {
    setBulletPoints([...bulletPoints, ""])
  }

  const updateBulletPoint = (index: number, value: string) => {
    const newPoints = [...bulletPoints]
    newPoints[index] = value
    setBulletPoints(newPoints)
  }

  const removeBulletPoint = (index: number) => {
    setBulletPoints(bulletPoints.filter((_, i) => i !== index))
  }

  const startPolling = useCallback(
    (jobId: string) => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
      }

      pollingRef.current = setInterval(async () => {
        try {
          const status = await videoApi.getStatus(jobId)
          setCurrentJob(status)

          if (status.status === "done") {
            // Stop polling
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            // Download video as blob
            try {
              const blob = await videoApi.download(jobId)
              const url = URL.createObjectURL(blob)
              setVideoUrl(url)

              toast({
                title: "Vídeo pronto!",
                description: "Seu vídeo foi gerado com sucesso.",
              })
            } catch (error) {
              toast({
                title: "Erro ao carregar preview",
                description: "Não foi possível carregar o vídeo.",
                variant: "destructive",
              })
            }

            setIsGenerating(false)
          } else if (status.status === "error") {
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            toast({
              title: "Erro na geração",
              description: status.error || "Ocorreu um erro ao gerar o vídeo.",
              variant: "destructive",
            })

            setIsGenerating(false)
          }
        } catch (error: any) {
          console.error("[v0] Polling error:", error)
          if (pollingRef.current) {
            clearInterval(pollingRef.current)
            pollingRef.current = null
          }
          setIsGenerating(false)
        }
      }, 1500)
    },
    [toast],
  )

  const handleGenerateVideo = async () => {
    // Validation
    if (!objetivo || !tema || !nicho || !palavraChave) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha objetivo, tema, nicho e palavra-chave.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setVideoUrl(null)
    setCurrentJob(null)

    try {
      // Build payload
      const payload: VideoPayload = {
        objetivo_video: objetivo,
        tema,
        nicho,
        palavra_chave_global: palavraChave,
        idioma,
        duracao,
        cenas,
        tipo_roteiro: tipoRoteiro,
        roteiro_sugerido_usuario: roteiroSugerido,
        bullet_points_roteiro: bulletPoints.filter((p) => p.trim() !== ""),
        usar_legenda_e_fala: usarLegenda,
        metadata: {
          duration: duracao,
          cenas,
          aspect_ratio: "9:16",
          usar_legenda_e_fala: usarLegenda,
        },
      }

      // Create FormData
      const formData = new FormData()
      formData.append("payload", JSON.stringify(payload))

      // Add files if any
      uploadedFiles.forEach((file) => {
        formData.append("files", file)
      })

      // Submit
      const response = await videoApi.render(formData)

      setCurrentJob({
        job_id: response.job_id,
        status: response.status,
        progress: 0,
        message: response.message,
        created_at: response.created_at,
        updated_at: response.created_at,
      })

      toast({
        title: "Vídeo em geração",
        description: "Acompanhe o progresso abaixo.",
      })

      // Start polling
      startPolling(response.job_id)
    } catch (error: any) {
      toast({
        title: "Erro ao gerar vídeo",
        description: error.message || "Tente novamente.",
        variant: "destructive",
      })
      setIsGenerating(false)
    }
  }

  const handleDownload = () => {
    if (!videoUrl || !currentJob) return

    const link = document.createElement("a")
    link.href = videoUrl
    link.download = `viralize-${currentJob.job_id}.mp4`
    link.click()
  }

  const getStatusStep = (status: string): number => {
    const steps: Record<string, number> = {
      queued: 0,
      script: 1,
      media: 2,
      render: 3,
      finalize: 4,
      done: 5,
    }
    return steps[status] || 0
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex min-h-0">
      {/* Left Panel - Preview/Status */}
      <div className="w-1/3 border-r border-border p-6 flex flex-col gap-6">
        <Card className="glassmorphic-card">
          <CardHeader>
            <CardTitle>Preview do Vídeo</CardTitle>
            <CardDescription>O vídeo aparecerá aqui quando finalizado</CardDescription>
          </CardHeader>
          <CardContent>
            {videoUrl ? (
              <div className="space-y-4">
                <video src={videoUrl} controls className="w-full rounded-lg shadow-lg" />
                <Button onClick={handleDownload} className="w-full gap-2">
                  <Download className="h-4 w-4" />
                  Baixar Vídeo
                </Button>
              </div>
            ) : (
              <div className="aspect-[9/16] bg-muted rounded-lg flex items-center justify-center">
                <div className="text-center text-muted-foreground p-4">
                  <Play className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">Prévia aparecerá quando o render finalizar</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Status Card */}
        {currentJob && (
          <Card className="glassmorphic-card">
            <CardHeader>
              <CardTitle>Status da Geração</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>
                    {VIDEO_STATUS_LABELS[currentJob.status as keyof typeof VIDEO_STATUS_LABELS] || currentJob.status}
                  </span>
                  <span>{currentJob.progress}%</span>
                </div>
                <Progress value={currentJob.progress} />
              </div>

              {/* Stepper */}
              <div className="flex items-center justify-between text-xs">
                {["queued", "script", "media", "render", "finalize", "done"].map((step, index) => {
                  const currentStep = getStatusStep(currentJob.status)
                  const isActive = index <= currentStep
                  return (
                    <div key={step} className="flex flex-col items-center gap-1">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                          isActive ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {index + 1}
                      </div>
                      <span className="text-[10px] text-muted-foreground capitalize">{step}</span>
                    </div>
                  )
                })}
              </div>

              {currentJob.message && <p className="text-sm text-muted-foreground">{currentJob.message}</p>}
              {currentJob.error && <p className="text-sm text-destructive">{currentJob.error}</p>}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Right Panel - Editor (SCROLLABLE) */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 min-h-0 overflow-y-auto p-6">
          <div className="max-w-3xl mx-auto space-y-6">
            <div>
              <h2 className="text-2xl font-heading font-bold gradient-text">Criar Novo Vídeo</h2>
              <p className="text-muted-foreground mt-1">Preencha os campos para gerar seu vídeo viral com IA</p>
            </div>

            <Tabs defaultValue="conteudo" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="conteudo">Conteúdo</TabsTrigger>
                <TabsTrigger value="roteiro">Roteiro</TabsTrigger>
                <TabsTrigger value="midias">Mídias</TabsTrigger>
                <TabsTrigger value="revisao">Revisão</TabsTrigger>
              </TabsList>

              {/* Tab: Conteúdo */}
              <TabsContent value="conteudo" className="space-y-4">
                <Card className="glassmorphic-card">
                  <CardHeader>
                    <CardTitle>Informações Básicas</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="objetivo">Objetivo do Vídeo *</Label>
                      <Input
                        id="objetivo"
                        placeholder="Ex: Aumentar vendas de curso"
                        value={objetivo}
                        onChange={(e) => setObjetivo(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="tema">Tema *</Label>
                      <Input
                        id="tema"
                        placeholder="Ex: Marketing Digital"
                        value={tema}
                        onChange={(e) => setTema(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="nicho">Nicho *</Label>
                      <Input
                        id="nicho"
                        placeholder="Ex: Empreendedores"
                        value={nicho}
                        onChange={(e) => setNicho(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="palavra-chave">Palavra-chave Global *</Label>
                      <Input
                        id="palavra-chave"
                        placeholder="Ex: vendas online"
                        value={palavraChave}
                        onChange={(e) => setPalavraChave(e.target.value)}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="idioma">Idioma</Label>
                        <Select value={idioma} onValueChange={setIdioma}>
                          <SelectTrigger id="idioma">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {IDIOMA_OPTIONS.map((opt) => (
                              <SelectItem key={opt.value} value={opt.value}>
                                {opt.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="tipo-roteiro">Tipo de Roteiro</Label>
                        <Select value={tipoRoteiro} onValueChange={setTipoRoteiro}>
                          <SelectTrigger id="tipo-roteiro">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {TIPO_ROTEIRO_OPTIONS.map((opt) => (
                              <SelectItem key={opt.value} value={opt.value}>
                                {opt.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="duracao">Duração (segundos): {duracao}s</Label>
                      <Slider
                        id="duracao"
                        min={15}
                        max={60}
                        step={5}
                        value={[duracao]}
                        onValueChange={(v) => setDuracao(v[0])}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="cenas">Número de Cenas: {cenas}</Label>
                      <Slider
                        id="cenas"
                        min={1}
                        max={10}
                        step={1}
                        value={[cenas]}
                        onValueChange={(v) => setCenas(v[0])}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="usar-legenda">Usar Legenda e Fala</Label>
                      <Switch id="usar-legenda" checked={usarLegenda} onCheckedChange={setUsarLegenda} />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tab: Roteiro */}
              <TabsContent value="roteiro" className="space-y-4">
                <Card className="glassmorphic-card">
                  <CardHeader>
                    <CardTitle>Roteiro Personalizado</CardTitle>
                    <CardDescription>Opcional - deixe em branco para a IA criar automaticamente</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="roteiro">Roteiro Sugerido</Label>
                      <Textarea
                        id="roteiro"
                        placeholder="Descreva o roteiro que você deseja..."
                        rows={6}
                        value={roteiroSugerido}
                        onChange={(e) => setRoteiroSugerido(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>Bullet Points do Roteiro</Label>
                        <Button type="button" size="sm" variant="outline" onClick={addBulletPoint}>
                          <Plus className="h-4 w-4 mr-1" />
                          Adicionar
                        </Button>
                      </div>

                      <div className="space-y-2">
                        {bulletPoints.map((point, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <GripVertical className="h-4 w-4 text-muted-foreground" />
                            <Input
                              placeholder={`Ponto ${index + 1}`}
                              value={point}
                              onChange={(e) => updateBulletPoint(index, e.target.value)}
                            />
                            <Button type="button" size="icon" variant="ghost" onClick={() => removeBulletPoint(index)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tab: Mídias */}
              <TabsContent value="midias" className="space-y-4">
                <Card className="glassmorphic-card">
                  <CardHeader>
                    <CardTitle>Upload de Vídeos</CardTitle>
                    <CardDescription>Opcional - se vazio, a IA escolhe mídia automaticamente</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div
                      className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground mb-2">
                        Clique para selecionar vídeos ou arraste aqui
                      </p>
                      <p className="text-xs text-muted-foreground">MP4, MOV - múltiplos arquivos permitidos</p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="video/mp4,video/quicktime"
                        multiple
                        className="hidden"
                        onChange={handleFileSelect}
                      />
                    </div>

                    {uploadedFiles.length > 0 && (
                      <div className="space-y-2">
                        <Label>Arquivos Selecionados ({uploadedFiles.length})</Label>
                        {uploadedFiles.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                            <div className="flex items-center gap-2">
                              <Play className="h-4 w-4 text-primary" />
                              <span className="text-sm">{file.name}</span>
                              <span className="text-xs text-muted-foreground">
                                ({(file.size / 1024 / 1024).toFixed(2)} MB)
                              </span>
                            </div>
                            <Button type="button" size="icon" variant="ghost" onClick={() => removeFile(index)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              {/* Tab: Revisão */}
              <TabsContent value="revisao" className="space-y-4">
                <Card className="glassmorphic-card">
                  <CardHeader>
                    <CardTitle>Resumo do Vídeo</CardTitle>
                    <CardDescription>Revise antes de gerar</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="font-semibold">Objetivo:</span> {objetivo || "-"}
                      </div>
                      <div>
                        <span className="font-semibold">Tema:</span> {tema || "-"}
                      </div>
                      <div>
                        <span className="font-semibold">Nicho:</span> {nicho || "-"}
                      </div>
                      <div>
                        <span className="font-semibold">Palavra-chave:</span> {palavraChave || "-"}
                      </div>
                      <div>
                        <span className="font-semibold">Duração:</span> {duracao}s
                      </div>
                      <div>
                        <span className="font-semibold">Cenas:</span> {cenas}
                      </div>
                      <div>
                        <span className="font-semibold">Idioma:</span>{" "}
                        {IDIOMA_OPTIONS.find((i) => i.value === idioma)?.label}
                      </div>
                      <div>
                        <span className="font-semibold">Roteiro:</span>{" "}
                        {TIPO_ROTEIRO_OPTIONS.find((t) => t.value === tipoRoteiro)?.label}
                      </div>
                    </div>

                    {uploadedFiles.length > 0 && (
                      <div>
                        <span className="font-semibold">Vídeos carregados:</span> {uploadedFiles.length} arquivo(s)
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Button
                  onClick={handleGenerateVideo}
                  disabled={isGenerating}
                  className="w-full neumorphic-button-primary h-12 text-base"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Gerando Vídeo...
                    </>
                  ) : (
                    "Gerar Vídeo"
                  )}
                </Button>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}
