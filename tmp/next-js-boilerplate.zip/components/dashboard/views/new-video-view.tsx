"use client"

import type React from "react"

import { useState } from "react"
import { ArrowLeft, Wand2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { videoApi } from "@/lib/api-client"
import { TIPO_ROTEIRO_OPTIONS, IDIOMA_OPTIONS } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

export function NewVideoView() {
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsGenerating(true)

    const formData = new FormData(e.currentTarget)

    try {
      const response = await videoApi.render(formData)
      toast({
        title: "Vídeo em produção!",
        description: "Seu vídeo está sendo gerado. Você pode acompanhar o progresso na lista.",
      })
    } catch (error: any) {
      toast({
        title: "Erro ao gerar vídeo",
        description: error.message,
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50">
      <div className="max-w-4xl mx-auto p-8">
        <Button variant="ghost" className="mb-6 gap-2">
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <Wand2 className="w-5 h-5 text-blue-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Criar novo vídeo</h1>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="objetivo_video">Objetivo do Vídeo</Label>
                <Input
                  id="objetivo_video"
                  name="objetivo_video"
                  placeholder="Ex: Engajar audiência, educar..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="tema">Tema</Label>
                <Input id="tema" name="tema" placeholder="Ex: Marketing digital" required />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="nicho">Nicho</Label>
                <Input id="nicho" name="nicho" placeholder="Ex: Empreendedorismo" required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="palavra_chave_global">Palavra-chave Global</Label>
                <Input id="palavra_chave_global" name="palavra_chave_global" placeholder="Ex: vendas online" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-6">
              <div className="space-y-2">
                <Label htmlFor="idioma">Idioma</Label>
                <Select name="idioma" defaultValue="pt-BR">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {IDIOMA_OPTIONS.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="duracao">Duração (segundos)</Label>
                <Input id="duracao" name="duracao" type="number" defaultValue={60} min={30} max={180} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cenas">Número de Cenas</Label>
                <Input id="cenas" name="cenas" type="number" defaultValue={5} min={3} max={10} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tipo_roteiro">Tipo de Roteiro</Label>
              <Select name="tipo_roteiro" defaultValue="educativo-com-prova-social">
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {TIPO_ROTEIRO_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="roteiro_sugerido_usuario">Roteiro Personalizado (Opcional)</Label>
              <Textarea
                id="roteiro_sugerido_usuario"
                name="roteiro_sugerido_usuario"
                placeholder="Descreva o roteiro que você quer..."
                rows={4}
              />
            </div>

            <Button
              type="submit"
              disabled={isGenerating}
              className="w-full bg-blue-600 hover:bg-blue-700 h-12 text-base font-medium"
            >
              {isGenerating ? (
                <>Gerando vídeo...</>
              ) : (
                <>
                  <Wand2 className="w-5 h-5 mr-2" />
                  Gerar Vídeo com IA
                </>
              )}
            </Button>
          </form>
        </div>
      </div>
    </main>
  )
}
