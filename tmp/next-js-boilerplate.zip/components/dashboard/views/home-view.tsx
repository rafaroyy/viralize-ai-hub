"use client"

import { useEffect, useState } from "react"
import { Search, Plus, FolderPlus, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { videoApi } from "@/lib/api-client"
import type { VideoListItem } from "@/lib/types"

const INSPIRATION_VIDEOS = [
  { id: 1, thumbnail: "/tiktok-video-1.png", title: "Como viralizar no TikTok" },
  { id: 2, thumbnail: "/instagram-reels-2.jpg", title: "Segredos do Instagram" },
  { id: 3, thumbnail: "/viral-content-3.jpg", title: "Conteúdo que engaja" },
  { id: 4, thumbnail: "/social-media-4.jpg", title: "Estratégia de conteúdo" },
  { id: 5, thumbnail: "/video-marketing-5.jpg", title: "Marketing digital" },
  { id: 6, thumbnail: "/content-creator-6.jpg", title: "Dicas para criadores" },
]

export function HomeView() {
  const [videos, setVideos] = useState<VideoListItem[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    loadVideos()
  }, [])

  const loadVideos = async () => {
    try {
      const data = await videoApi.list()
      setVideos(data)
    } catch (error) {
      console.error("[v0] Failed to load videos:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const filteredVideos = videos.filter((video) =>
    video.payload?.tema?.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <main className="flex-1 overflow-y-auto bg-gray-50">
      <div className="max-w-7xl mx-auto p-8 space-y-8">
        <section>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Inspire-se para o seu próximo vídeo</h2>

          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {INSPIRATION_VIDEOS.map((video) => (
              <div key={video.id} className="flex-shrink-0 w-[180px] group cursor-pointer">
                <div className="relative aspect-[9/16] rounded-xl overflow-hidden bg-gradient-to-br from-gray-200 to-gray-300 mb-2">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <Play className="w-12 h-12 text-white" fill="white" />
                  </div>
                </div>
                <p className="text-sm font-medium text-gray-700 line-clamp-2">{video.title}</p>
              </div>
            ))}
          </div>
        </section>

        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">Meus vídeos</h2>

            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar projetos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 w-64"
                />
              </div>

              <Button variant="outline" className="gap-2 bg-transparent">
                <FolderPlus className="w-4 h-4" />
                Nova pasta
              </Button>

              <Button className="gap-2 bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4" />
                Novo vídeo
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="aspect-[9/16] bg-gray-200 animate-pulse rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredVideos.map((video) => (
                <div key={video.job_id} className="group cursor-pointer">
                  <div className="relative aspect-[9/16] rounded-xl overflow-hidden bg-gradient-to-br from-gray-200 to-gray-300 mb-3">
                    <img
                      src={`/.jpg?height=400&width=225&query=${video.payload?.tema || "video"}`}
                      alt={video.payload?.tema || "Vídeo"}
                      className="w-full h-full object-cover"
                    />

                    {video.status === "done" && (
                      <div className="absolute top-3 right-3">
                        <div className="bg-green-500 text-white text-xs font-semibold px-3 py-1 rounded-full">
                          Pronto
                        </div>
                      </div>
                    )}

                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play className="w-12 h-12 text-white" fill="white" />
                    </div>
                  </div>

                  <h3 className="text-sm font-medium text-gray-900 line-clamp-2">
                    {video.payload?.tema || "Sem título"}
                  </h3>
                  <p className="text-xs text-gray-500 mt-1">{new Date(video.created_at).toLocaleDateString("pt-BR")}</p>
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  )
}
