"use client"

import { HomeView } from "./views/home-view"
import { NewVideoView } from "./views/new-video-view"

interface DashboardContentProps {
  activeSection: string
}

export function DashboardContent({ activeSection }: DashboardContentProps) {
  if (activeSection === "new-video") {
    return <NewVideoView />
  }

  return <HomeView />
}
