"use client"
import { useRouter } from "next/navigation"
import {
  Home,
  Upload,
  BarChart3,
  Video,
  Download,
  Zap,
  Bot,
  ImageIcon,
  RefreshCw,
  FileText,
  Lightbulb,
  LogOut,
  ChevronDown,
  User,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { authApi } from "@/lib/api-client"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface DashboardSidebarProps {
  username: string
  activeSection: string
  onSectionChange: (section: string) => void
}

const MENU_ITEMS = [
  { id: "home", label: "Home", icon: Home },
  { id: "publish", label: "Publicar", icon: Upload },
  { id: "stats", label: "Estatísticas", icon: BarChart3 },
  { id: "videos", label: "Vídeos", icon: Video },
  { id: "exports", label: "Exportações", icon: Download },
  { id: "auto", label: "Auto-Modo", icon: Zap },
  { id: "characters", label: "Personagens IA", icon: Bot },
  { id: "media", label: "Geração de Mídia", icon: ImageIcon },
  { id: "repurpose", label: "Repurpose", icon: RefreshCw },
  { id: "scripts", label: "Scripts", icon: FileText },
  { id: "hooks", label: "Hooks", icon: Lightbulb },
]

export function DashboardSidebar({ username, activeSection, onSectionChange }: DashboardSidebarProps) {
  const router = useRouter()

  const handleLogout = () => {
    authApi.logout()
    router.push("/login")
  }

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center">
            <span className="text-white font-bold text-sm">V</span>
          </div>
          <span className="font-semibold text-gray-900">Viralize AI</span>
        </div>

        <Button
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium"
          onClick={() => onSectionChange("new-video")}
        >
          + Criar novo vídeo
        </Button>
      </div>

      <nav className="flex-1 p-4 overflow-y-auto">
        <div className="space-y-1">
          {MENU_ITEMS.map((item) => {
            const Icon = item.icon
            const isActive = activeSection === item.id

            return (
              <button
                key={item.id}
                onClick={() => onSectionChange(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  isActive ? "bg-blue-50 text-blue-700" : "text-gray-700 hover:bg-gray-50"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            )
          })}
        </div>
      </nav>

      <div className="p-4 border-t border-gray-200">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-50 transition-colors">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-medium text-gray-900">{username}</p>
                <p className="text-xs text-gray-500">Membro Premium</p>
              </div>
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem onClick={handleLogout} className="text-red-600">
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </aside>
  )
}
