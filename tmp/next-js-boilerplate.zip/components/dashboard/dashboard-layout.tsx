"use client"

import { useState } from "react"
import { DashboardSidebar } from "./dashboard-sidebar"
import { DashboardContent } from "./dashboard-content"

interface DashboardLayoutProps {
  username: string
}

export function DashboardLayout({ username }: DashboardLayoutProps) {
  const [activeSection, setActiveSection] = useState("home")

  return (
    <div className="flex h-screen bg-gray-50">
      <DashboardSidebar username={username} activeSection={activeSection} onSectionChange={setActiveSection} />

      <DashboardContent activeSection={activeSection} />
    </div>
  )
}
