"use client"

import { VideoHistory } from "@/components/video-editor/video-history"

export function HistoryView() {
  return (
    <div className="flex-1 overflow-y-auto">
      <VideoHistory />
    </div>
  )
}
