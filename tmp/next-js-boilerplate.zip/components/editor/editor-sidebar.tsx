"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import type { VideoStatusResponse } from "@/lib/types"

interface EditorSidebarProps {
  currentJob: VideoStatusResponse | null
}

export function EditorSidebar({ currentJob }: EditorSidebarProps) {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-xl font-heading font-bold gradient-text">Detalhes & Roteiro</h3>
        <p className="text-sm text-muted-foreground mt-1">Informações sobre o vídeo</p>
      </div>

      {currentJob ? (
        <Tabs defaultValue="detalhes" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="detalhes">Detalhes</TabsTrigger>
            <TabsTrigger value="checklist">Checklist</TabsTrigger>
          </TabsList>

          <TabsContent value="detalhes" className="space-y-4 mt-4">
            <Card className="glassmorphic-card">
              <CardHeader>
                <CardTitle className="text-sm">Informações do Job</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <span className="text-muted-foreground">Job ID:</span>
                  <p className="font-mono text-xs mt-1 bg-muted p-2 rounded">{currentJob.job_id}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Status:</span>
                  <p className="mt-1">
                    <Badge
                      variant={
                        currentJob.status === "done"
                          ? "default"
                          : currentJob.status === "error"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {currentJob.status}
                    </Badge>
                  </p>
                </div>
                <div>
                  <span className="text-muted-foreground">Criado em:</span>
                  <p className="mt-1">{new Date(currentJob.created_at).toLocaleString("pt-BR")}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Última atualização:</span>
                  <p className="mt-1">{new Date(currentJob.updated_at).toLocaleString("pt-BR")}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="checklist" className="space-y-4 mt-4">
            <Card className="glassmorphic-card">
              <CardHeader>
                <CardTitle className="text-sm">Checklist Viral</CardTitle>
                <CardDescription className="text-xs">Elementos essenciais para viralização</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs">✓</span>
                  </div>
                  <div>
                    <p className="font-semibold">Hook nos 3 primeiros segundos</p>
                    <p className="text-xs text-muted-foreground mt-1">Capturar atenção imediatamente</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs">✓</span>
                  </div>
                  <div>
                    <p className="font-semibold">CTA claro e direto</p>
                    <p className="text-xs text-muted-foreground mt-1">Call-to-action efetivo</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs">✓</span>
                  </div>
                  <div>
                    <p className="font-semibold">Ritmo dinâmico</p>
                    <p className="text-xs text-muted-foreground mt-1">Cortes e transições rápidas</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs">✓</span>
                  </div>
                  <div>
                    <p className="font-semibold">Legenda sincronizada</p>
                    <p className="text-xs text-muted-foreground mt-1">Acessibilidade e retenção</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      ) : (
        <Card className="glassmorphic-card">
          <CardContent className="flex items-center justify-center py-12">
            <p className="text-sm text-muted-foreground text-center">
              Configure e gere um vídeo para ver os detalhes aqui
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
