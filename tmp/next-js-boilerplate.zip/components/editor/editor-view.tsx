"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { Play, Download } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { videoApi } from "@/lib/api-client"
import type { VideoPayload, VideoStatusResponse } from "@/lib/types"
import { VIDEO_STATUS_LABELS } from "@/lib/types"
import { EditorForm } from "./editor-form"
import { EditorSidebar } from "./editor-sidebar"

export function EditorView() {
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentJob, setCurrentJob] = useState<VideoStatusResponse | null>(null)
  const [videoUrl, setVideoUrl] = useState<string | null>(null)
  const pollingRef = useRef<NodeJS.Timeout | null>(null)

  // Cleanup polling on unmount
  useEffect(() => {
    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current)
        pollingRef.current = null
      }
      if (videoUrl) {
        URL.revokeObjectURL(videoUrl)
      }
    }
  }, [videoUrl])

  const startPolling = useCallback(
    (jobId: string) => {
      if (pollingRef.current) clearInterval(pollingRef.current)

      pollingRef.current = setInterval(async () => {
        try {
          const status = await videoApi.getStatus(jobId)
          setCurrentJob(status)

          // Check for completion
          if (status.status === "done" || status.status === "completed" || status.status === "success") {
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            // Download video and create blob URL
            try {
              const blob = await videoApi.download(jobId)
              const url = URL.createObjectURL(blob)
              setVideoUrl(url)

              toast({
                title: "Vídeo pronto!",
                description: "Seu vídeo foi gerado com sucesso.",
              })
            } catch (error: any) {
              console.error("[v0] Download error:", error)
              toast({
                title: "Erro ao carregar preview",
                description: error.message || "Não foi possível carregar o vídeo.",
                variant: "destructive",
              })
            }

            setIsGenerating(false)
          } else if (status.status === "error" || status.status === "failed") {
            if (pollingRef.current) {
              clearInterval(pollingRef.current)
              pollingRef.current = null
            }

            toast({
              title: "Erro na geração",
              description: status.error || "Ocorreu um erro ao gerar o vídeo.",
              variant: "destructive",
            })

            setIsGenerating(false)
          }
        } catch (error: any) {
          console.error("[v0] Polling error:", error)
          if (pollingRef.current) {
            clearInterval(pollingRef.current)
            pollingRef.current = null
          }
          setIsGenerating(false)
        }
      }, 2500) // Poll every 2.5s
    },
    [toast],
  )

  const handleGenerate = async (payload: VideoPayload, files: File[]) => {
    setIsGenerating(true)
    setVideoUrl(null)
    setCurrentJob(null)

    try {
      // Create FormData
      const formData = new FormData()
      formData.append("payload", JSON.stringify(payload))

      // Add files
      files.forEach((file) => {
        formData.append("files", file)
      })

      // Submit to API
      const response = await videoApi.render(formData)

      setCurrentJob({
        job_id: response.job_id,
        status: response.status,
        progress: 0,
        message: response.message || "Processando...",
        created_at: response.created_at,
        updated_at: response.created_at,
      })

      toast({
        title: "Vídeo em geração",
        description: "Acompanhe o progresso no painel central.",
      })

      // Start polling
      startPolling(response.job_id)
    } catch (error: any) {
      console.error("[v0] Generation error:", error)
      toast({
        title: "Erro ao gerar vídeo",
        description: error.message || "Tente novamente.",
        variant: "destructive",
      })
      setIsGenerating(false)
    }
  }

  const handleDownload = () => {
    if (!videoUrl || !currentJob) return

    const link = document.createElement("a")
    link.href = videoUrl
    link.download = `viralize-${currentJob.job_id}.mp4`
    link.click()
  }

  return (
    <div className="h-[calc(100vh-4rem)] flex min-h-0">
      {/* Left Column - Configuration Form (SCROLLABLE) */}
      <div className="w-[380px] border-r border-border flex flex-col min-h-0">
        <div className="flex-1 min-h-0 overflow-y-auto p-6">
          <EditorForm onGenerate={handleGenerate} isGenerating={isGenerating} />
        </div>
      </div>

      {/* Center Column - Preview/Player (FIXED HEIGHT) */}
      <div className="flex-1 min-h-0 p-6 flex flex-col gap-6">
        {/* Video Preview Card */}
        <Card className="glassmorphic-card flex-shrink-0">
          <CardHeader>
            <CardTitle>Preview do Vídeo</CardTitle>
            <CardDescription>O vídeo aparecerá aqui quando finalizado</CardDescription>
          </CardHeader>
          <CardContent>
            {videoUrl ? (
              <div className="space-y-4">
                <div className="aspect-[9/16] max-h-[500px] mx-auto">
                  <video src={videoUrl} controls className="w-full h-full rounded-lg shadow-2xl object-cover" />
                </div>
                <Button onClick={handleDownload} className="w-full gap-2" size="lg">
                  <Download className="h-5 w-5" />
                  Baixar Vídeo
                </Button>
              </div>
            ) : (
              <div className="aspect-[9/16] max-h-[500px] mx-auto bg-muted/50 rounded-lg flex items-center justify-center border-2 border-dashed border-muted-foreground/25">
                <div className="text-center text-muted-foreground p-6">
                  <Play className="h-16 w-16 mx-auto mb-4 opacity-30" />
                  <p className="text-sm font-medium">Aguardando geração</p>
                  <p className="text-xs mt-2">O preview aparecerá aqui quando o vídeo estiver pronto</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Status Card */}
        {currentJob && (
          <Card className="glassmorphic-card flex-shrink-0">
            <CardHeader>
              <CardTitle className="text-lg">Status da Geração</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2 font-medium">
                  <span>
                    {VIDEO_STATUS_LABELS[currentJob.status as keyof typeof VIDEO_STATUS_LABELS] || currentJob.status}
                  </span>
                  <span>{currentJob.progress || 0}%</span>
                </div>
                <Progress value={currentJob.progress || 0} className="h-2" />
              </div>

              {/* Progress Steps */}
              <div className="flex items-center justify-between">
                {["queued", "script", "media", "render", "finalize", "done"].map((step, index) => {
                  const steps: Record<string, number> = {
                    queued: 0,
                    script: 1,
                    media: 2,
                    render: 3,
                    finalize: 4,
                    done: 5,
                  }
                  const currentStep = steps[currentJob.status] || 0
                  const isActive = index <= currentStep

                  return (
                    <div key={step} className="flex flex-col items-center gap-1.5 flex-1">
                      <div
                        className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold text-sm transition-all ${
                          isActive ? "bg-primary text-primary-foreground scale-110" : "bg-muted text-muted-foreground"
                        }`}
                      >
                        {index + 1}
                      </div>
                      <span className="text-[10px] text-center text-muted-foreground capitalize">{step}</span>
                    </div>
                  )
                })}
              </div>

              {currentJob.message && (
                <p className="text-sm text-muted-foreground border-l-2 border-primary pl-3">{currentJob.message}</p>
              )}
              {currentJob.error && (
                <p className="text-sm text-destructive border-l-2 border-destructive pl-3">{currentJob.error}</p>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Right Column - Roteiro & Detalhes (SCROLLABLE) */}
      <div className="w-[380px] border-l border-border flex flex-col min-h-0">
        <div className="flex-1 min-h-0 overflow-y-auto p-6">
          <EditorSidebar currentJob={currentJob} />
        </div>
      </div>
    </div>
  )
}
