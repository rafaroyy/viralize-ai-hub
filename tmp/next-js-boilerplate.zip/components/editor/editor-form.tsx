"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Plus, X, Upload, GripVertical } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import type { VideoPayload } from "@/lib/types"
import { TIPO_ROTEIRO_OPTIONS, IDIOMA_OPTIONS } from "@/lib/types"

interface EditorFormProps {
  onGenerate: (payload: VideoPayload, files: File[]) => void
  isGenerating: boolean
}

export function EditorForm({ onGenerate, isGenerating }: EditorFormProps) {
  const { toast } = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Form state
  const [objetivo, setObjetivo] = useState("")
  const [tema, setTema] = useState("")
  const [nicho, setNicho] = useState("")
  const [palavraChave, setPalavraChave] = useState("")
  const [idioma, setIdioma] = useState("pt-BR")
  const [duracao, setDuracao] = useState(30)
  const [cenas, setCenas] = useState(3)
  const [tipoRoteiro, setTipoRoteiro] = useState("educativo-com-prova-social")
  const [roteiroSugerido, setRoteiroSugerido] = useState("")
  const [bulletPoints, setBulletPoints] = useState<string[]>([""])
  const [usarLegenda, setUsarLegenda] = useState(true)
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files)
      setUploadedFiles((prev) => [...prev, ...files])
    }
  }

  const removeFile = (index: number) => {
    setUploadedFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const addBulletPoint = () => {
    setBulletPoints([...bulletPoints, ""])
  }

  const updateBulletPoint = (index: number, value: string) => {
    const newPoints = [...bulletPoints]
    newPoints[index] = value
    setBulletPoints(newPoints)
  }

  const removeBulletPoint = (index: number) => {
    if (bulletPoints.length > 1) {
      setBulletPoints(bulletPoints.filter((_, i) => i !== index))
    }
  }

  const handleSubmit = () => {
    // Validation
    if (!objetivo || !tema || !nicho || !palavraChave) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha objetivo, tema, nicho e palavra-chave.",
        variant: "destructive",
      })
      return
    }

    const payload: VideoPayload = {
      objetivo_video: objetivo,
      tema,
      nicho,
      palavra_chave_global: palavraChave,
      idioma,
      duracao,
      cenas,
      tipo_roteiro: tipoRoteiro,
      roteiro_sugerido_usuario: roteiroSugerido,
      bullet_points_roteiro: bulletPoints.filter((p) => p.trim() !== ""),
      usar_legenda_e_fala: usarLegenda,
      metadata: {
        duration: duracao,
        cenas,
        aspect_ratio: "9:16",
        usar_legenda_e_fala: usarLegenda,
      },
    }

    onGenerate(payload, uploadedFiles)
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-heading font-bold gradient-text">Configuração do Vídeo</h3>
        <p className="text-sm text-muted-foreground mt-1">Preencha os campos abaixo</p>
      </div>

      {/* Campos Essenciais */}
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="objetivo" className="text-sm font-semibold">
            Objetivo do Vídeo <span className="text-destructive">*</span>
          </Label>
          <Input
            id="objetivo"
            placeholder="Ex: Aumentar vendas do curso"
            value={objetivo}
            onChange={(e) => setObjetivo(e.target.value)}
            disabled={isGenerating}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="tema" className="text-sm font-semibold">
            Tema <span className="text-destructive">*</span>
          </Label>
          <Input
            id="tema"
            placeholder="Ex: Marketing Digital"
            value={tema}
            onChange={(e) => setTema(e.target.value)}
            disabled={isGenerating}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="nicho" className="text-sm font-semibold">
            Nicho <span className="text-destructive">*</span>
          </Label>
          <Input
            id="nicho"
            placeholder="Ex: Empreendedores"
            value={nicho}
            onChange={(e) => setNicho(e.target.value)}
            disabled={isGenerating}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="palavra-chave" className="text-sm font-semibold">
            Palavra-chave Global <span className="text-destructive">*</span>
          </Label>
          <Input
            id="palavra-chave"
            placeholder="Ex: vendas online"
            value={palavraChave}
            onChange={(e) => setPalavraChave(e.target.value)}
            disabled={isGenerating}
          />
        </div>
      </div>

      <Separator />

      {/* Configurações Avançadas */}
      <div className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-2">
            <Label htmlFor="idioma" className="text-xs font-semibold">
              Idioma
            </Label>
            <Select value={idioma} onValueChange={setIdioma} disabled={isGenerating}>
              <SelectTrigger id="idioma" className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {IDIOMA_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tipo-roteiro" className="text-xs font-semibold">
              Tipo de Roteiro
            </Label>
            <Select value={tipoRoteiro} onValueChange={setTipoRoteiro} disabled={isGenerating}>
              <SelectTrigger id="tipo-roteiro" className="h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TIPO_ROTEIRO_OPTIONS.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="duracao" className="text-xs font-semibold">
            Duração: <span className="text-primary">{duracao}s</span>
          </Label>
          <Slider
            id="duracao"
            min={15}
            max={60}
            step={5}
            value={[duracao]}
            onValueChange={(v) => setDuracao(v[0])}
            disabled={isGenerating}
            className="py-2"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="cenas" className="text-xs font-semibold">
            Número de Cenas: <span className="text-primary">{cenas}</span>
          </Label>
          <Slider
            id="cenas"
            min={1}
            max={10}
            step={1}
            value={[cenas]}
            onValueChange={(v) => setCenas(v[0])}
            disabled={isGenerating}
            className="py-2"
          />
        </div>

        <div className="flex items-center justify-between py-2">
          <Label htmlFor="usar-legenda" className="text-sm font-medium">
            Usar Legenda e Fala
          </Label>
          <Switch id="usar-legenda" checked={usarLegenda} onCheckedChange={setUsarLegenda} disabled={isGenerating} />
        </div>
      </div>

      <Separator />

      {/* Roteiro Personalizado */}
      <div className="space-y-4">
        <div>
          <Label className="text-sm font-semibold">Roteiro Personalizado</Label>
          <p className="text-xs text-muted-foreground mt-1">Opcional - deixe em branco para IA criar</p>
        </div>

        <Textarea
          placeholder="Descreva o roteiro que você deseja..."
          rows={4}
          value={roteiroSugerido}
          onChange={(e) => setRoteiroSugerido(e.target.value)}
          disabled={isGenerating}
          className="resize-none"
        />

        <div>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-xs font-semibold">Bullet Points</Label>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={addBulletPoint}
              disabled={isGenerating}
              className="h-7 text-xs"
            >
              <Plus className="h-3 w-3 mr-1" />
              Adicionar
            </Button>
          </div>

          <div className="space-y-2">
            {bulletPoints.map((point, index) => (
              <div key={index} className="flex items-center gap-2">
                <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                <Input
                  placeholder={`Ponto ${index + 1}`}
                  value={point}
                  onChange={(e) => updateBulletPoint(index, e.target.value)}
                  disabled={isGenerating}
                  className="h-9"
                />
                {bulletPoints.length > 1 && (
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    onClick={() => removeBulletPoint(index)}
                    disabled={isGenerating}
                    className="h-9 w-9 flex-shrink-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      <Separator />

      {/* Upload de Vídeos */}
      <div className="space-y-3">
        <div>
          <Label className="text-sm font-semibold">Vídeos Personalizados</Label>
          <p className="text-xs text-muted-foreground mt-1">Opcional - IA escolhe automaticamente se vazio</p>
        </div>

        <div
          className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4 text-center cursor-pointer hover:border-primary/50 transition-colors"
          onClick={() => !isGenerating && fileInputRef.current?.click()}
        >
          <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
          <p className="text-xs text-muted-foreground">Clique para selecionar ou arraste vídeos</p>
          <p className="text-[10px] text-muted-foreground mt-1">MP4, MOV - múltiplos arquivos</p>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/mp4,video/quicktime"
            multiple
            className="hidden"
            onChange={handleFileSelect}
            disabled={isGenerating}
          />
        </div>

        {uploadedFiles.length > 0 && (
          <div className="space-y-2">
            {uploadedFiles.map((file, index) => (
              <div key={index} className="flex items-center justify-between gap-2 p-2 bg-muted rounded text-xs">
                <span className="truncate flex-1">{file.name}</span>
                <span className="text-muted-foreground flex-shrink-0">{(file.size / 1024 / 1024).toFixed(1)} MB</span>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  onClick={() => removeFile(index)}
                  disabled={isGenerating}
                  className="h-6 w-6 flex-shrink-0"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <Separator />

      {/* CTA */}
      <Button onClick={handleSubmit} disabled={isGenerating} className="w-full h-11 text-base font-semibold" size="lg">
        {isGenerating ? "Gerando..." : "Gerar Vídeo"}
      </Button>
    </div>
  )
}
