"use client"

import { motion } from "framer-motion"
import { FileText, Wand2, Video, TrendingUp } from 'lucide-react'
import { ScrollReveal } from "@/components/scroll-reveal"
import { Card } from "@/components/ui/card"
import { AnimatedBackground } from "@/components/ui/animated-background"

export function WorkflowSection() {
  const steps = [
    {
      number: "01",
      title: "Descreva seu Vídeo",
      description: "Digite o que você quer que o vídeo comunique. A IA entenderá seu objetivo e frameworks necessários.",
      icon: <FileText className="h-8 w-8 text-purple-500" />,
      details: ["Produto ou serviço", "Público-alvo", "Objetivo de venda"],
    },
    {
      number: "02",
      title: "IA Gera o Criativo",
      description: "Nossos frameworks analisam seu prompt e geram um vídeo otimizado para viralizar.",
      icon: <Wand2 className="h-8 w-8 text-blue-500" />,
      details: ["Copy visual", "Sequência de frames", "Gatilhos de atenção"],
    },
    {
      number: "03",
      title: "Customize e Exporte",
      description: "Ajuste cores, textos e timing. Exporte em qualidade profissional para suas redes.",
      icon: <Video className="h-8 w-8 text-purple-500" />,
      details: ["Edição rápida", "Múltiplos formatos", "Otimizado por rede"],
    },
    {
      number: "04",
      title: "Monitore e Otimize",
      description: "Acompanhe performance em tempo real e use insights para melhorar próximos vídeos.",
      icon: <TrendingUp className="h-8 w-8 text-blue-500" />,
      details: ["Analytics ao vivo", "Recomendações AI", "A/B Testing"],
    },
  ]

  return (
    <section id="how-it-works" className="relative w-full py-12 md:py-24 lg:py-32 overflow-hidden">
      <AnimatedBackground variant="gradient" color="rgba(168, 85, 247, 0.05)" secondaryColor="rgba(59, 130, 246, 0.05)" />

      <div className="container px-6 md:px-8">
        <ScrollReveal>
          <div className="flex flex-col items-center justify-center space-y-4 text-center mb-16">
            <div className="space-y-2">
              <h2 className="text-3xl font-heading font-bold tracking-tighter sm:text-5xl">
                Como Funciona em 4 Passos
              </h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed dark:text-gray-400 opacity-70">
                Do prompt ao vídeo viral em minutos. Simples, rápido e poderoso.
              </p>
            </div>
          </div>
        </ScrollReveal>

        <div className="grid gap-8 md:gap-12">
          {steps.map((step, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className={`flex gap-8 items-start ${index % 2 === 1 ? "md:flex-row-reverse" : ""}`}
              >
                {/* Step Circle and Line */}
                <div className="relative flex flex-col items-center flex-shrink-0">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="w-20 h-20 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center text-white font-heading font-bold text-2xl border-4 border-background shadow-lg"
                  >
                    {step.number}
                  </motion.div>
                  {index < steps.length - 1 && (
                    <motion.div
                      initial={{ height: 0 }}
                      whileInView={{ height: 120 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.6, delay: 0.3 }}
                      className="w-1 bg-gradient-to-b from-purple-600 to-blue-600 my-4"
                    />
                  )}
                </div>

                {/* Content Card */}
                <div className="flex-1 pt-2">
                  <Card className="glassmorphic-card border-glow-purple p-8 h-full">
                    <div className="flex gap-4 mb-4">
                      {step.icon}
                    </div>
                    <h3 className="text-2xl font-heading font-bold mb-2">{step.title}</h3>
                    <p className="text-muted-foreground mb-6">{step.description}</p>
                    
                    <div className="grid grid-cols-3 gap-3">
                      {step.details.map((detail, i) => (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, y: 5 }}
                          whileInView={{ opacity: 1, y: 0 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.3, delay: 0.1 * i }}
                          className="text-xs bg-purple-500/10 border border-purple-500/30 rounded-md py-2 px-3 text-center text-purple-300"
                        >
                          {detail}
                        </motion.div>
                      ))}
                    </div>
                  </Card>
                </div>
              </motion.div>
            </ScrollReveal>
          ))}
        </div>

        {/* Time-to-value */}
        <ScrollReveal>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mt-16 bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-xl border border-purple-500/30 p-8 text-center"
          >
            <h3 className="text-2xl font-heading font-bold mb-2">
              Tempo Médio: <span className="gradient-text">2 Minutos</span>
            </h3>
            <p className="text-muted-foreground">
              Do prompt ao vídeo pronto para publicar. Sem necessidade de conhecimentos técnicos em edição.
            </p>
          </motion.div>
        </ScrollReveal>
      </div>
    </section>
  )
}
