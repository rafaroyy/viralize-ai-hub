"use client"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { ScrollReveal } from "@/components/scroll-reveal"

export function FaqSection() {
  const faqs = [
    {
      question: "Como a Viralize AI funciona?",
      answer:
        "A Viralize AI usa frameworks testados em mais de 500 milhões de visualizações orgânicas para criar vídeos virais. Você descreve o que quer, nossa IA gera o criativo completo (roteiro, edição, legendas) e em 5 minutos seu vídeo está pronto para publicar.",
    },
    {
      question: "Preciso ter experiência em edição de vídeo?",
      answer:
        "Não! A Viralize AI foi criada justamente para quem não tem tempo ou conhecimento técnico. Nossa IA faz todo o trabalho pesado, desde o roteiro até a edição final. Você só precisa aprovar e publicar.",
    },
    {
      question: "Qual é a diferença entre o plano Mensal e Trimestral?",
      answer:
        "O plano Mensal (R$ 97/mês) oferece acesso ao Cérebro Viral com frameworks básicos, perfeito para começar. O plano Trimestral (R$ 197 a cada 3 meses) inclui todos os frameworks básicos e avançados, análise de conversão e suporte prioritário - a melhor relação custo-benefício.",
    },
    {
      question: "Posso usar os vídeos comercialmente?",
      answer:
        "Sim! Todos os vídeos criados com a Viralize AI são 100% seus. Você pode usar em seus próprios canais, para clientes, revender ou como quiser. Não há restrições de uso comercial.",
    },
    {
      question: "Como funciona a garantia de 7 dias?",
      answer:
        "Se você não ficar satisfeito com a Viralize AI nos primeiros 7 dias, devolvemos 100% do seu dinheiro, sem perguntas. Queremos que você teste a plataforma sem riscos e veja os resultados por si mesmo.",
    },
    {
      question: "Que tipo de suporte está incluído em cada plano?",
      answer:
        "O plano Mensal inclui suporte por email para dúvidas gerais. O plano Trimestral oferece suporte prioritário, garantindo respostas mais rápidas e acesso a recursos avançados como relatórios de performance detalhados.",
    },
  ]

  return (
    <section id="faq" className="w-full py-12 md:py-24 lg:py-32 bg-muted/30">
      <div className="container px-4 md:px-6">
        <ScrollReveal>
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-heading font-bold tracking-tighter sm:text-5xl">
                Perguntas Frequentes
              </h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 opacity-70">
                Tire suas dúvidas sobre como a Viralize AI pode transformar sua criação de conteúdo.
              </p>
            </div>
          </div>
        </ScrollReveal>

        <div className="mx-auto max-w-3xl py-12">
          <ScrollReveal>
            <Accordion type="single" collapsible className="w-full">
              {faqs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`} className="glassmorphic-accordion-item">
                  <AccordionTrigger className="text-left font-medium tracking-tight">{faq.question}</AccordionTrigger>
                  <AccordionContent className="text-muted-foreground opacity-70">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </ScrollReveal>
        </div>
      </div>
    </section>
  )
}
