"use client"
import { Zap, Brain, Sparkles, Target, TrendingUp, Lock } from 'lucide-react'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { GlowingTiltCard } from "@/components/ui/glowing-tilt-card"
import { ParallaxScroll } from "@/components/ui/parallax-scroll"
import { AnimatedText } from "@/components/ui/animated-text"
import { AnimatedBackground } from "@/components/ui/animated-background"

export function FeaturesSection() {
  const features = [
    {
      icon: <Brain className="h-10 w-10 text-purple-500" />,
      title: "Frameworks de Viralização",
      description: "Acesse aos mesmos frameworks que geraram +500M de views orgânicos no TikTok e Instagram.",
      borderClass: "border-glow-purple",
    },
    {
      icon: <Target className="h-10 w-10 text-blue-500" />,
      title: "Copy Visual Inteligente",
      description: "Cada frame é pensado para segurar atenção. Estrutura persuasiva validada em milhões de impressões.",
      borderClass: "border-glow-blue",
    },
    {
      icon: <Sparkles className="h-10 w-10 text-purple-400" />,
      title: "Gatilhos de Venda",
      description: "Vídeos que não só viralizam, mas vendem. Emoção + curiosidade + call to action em cada criativo.",
      borderClass: "border-glow-purple",
    },
    {
      icon: <Zap className="h-10 w-10 text-blue-400" />,
      title: "Criação em 5 Minutos",
      description: "Do prompt ao vídeo pronto. Tempo médio de criação 5 minutos com qualidade profissional.",
      borderClass: "border-glow-blue",
    },
    {
      icon: <TrendingUp className="h-10 w-10 text-purple-500" />,
      title: "Otimizado para Algoritmos",
      description: "95% de taxa de viralização. Vídeos otimizados para os algoritmos do TikTok e Instagram.",
      borderClass: "border-glow-purple",
    },
    {
      icon: <Lock className="h-10 w-10 text-blue-500" />,
      title: "Cérebro de Especialista",
      description: "Criada por quem domina o orgânico. Acesse a mente de quem vive de vídeos virais.",
      borderClass: "border-glow-blue",
    },
  ]

  return (
    <section id="frameworks" className="relative w-full py-12 md:py-24 lg:py-32 bg-muted/30 overflow-hidden">
      <AnimatedBackground variant="dots" color="rgba(168, 85, 247, 0.05)" />

      <div className="container px-6 md:px-8">
        <ScrollReveal>
          <div className="flex flex-col items-center justify-center space-y-6 text-center mb-12">
            <div className="space-y-4">
              <AnimatedText
                text="O Que Faz a Diferença"
                variant="heading"
                className="text-3xl font-heading font-bold tracking-tighter sm:text-5xl gradient-text"
                animation="slide"
              />
              <AnimatedText
                text="Entenda por que a Viralize AI é diferente de outras ferramentas de criação de vídeos."
                variant="paragraph"
                className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 opacity-70"
                animation="fade"
                delay={0.3}
              />
            </div>
          </div>
        </ScrollReveal>

        <ParallaxScroll baseVelocity={0.1} direction="up" className="py-12">
          <div className="mx-auto grid max-w-6xl grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <ScrollReveal key={index} delay={index * 0.1}>
                <GlowingTiltCard>
                  <Card className={`h-full glassmorphic-card border-none overflow-hidden group soft-glow ${feature.borderClass}`}>
                    <CardHeader>
                      <div className="p-2 rounded-xl w-fit bg-muted/50 transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                        {feature.icon}
                      </div>
                      <CardTitle className="mt-4 tracking-tight relative">
                        {feature.title}
                        <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-purple-500 transition-all duration-300 group-hover:w-full"></span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <CardDescription className="text-base opacity-70 transition-opacity duration-300 group-hover:opacity-100">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </GlowingTiltCard>
              </ScrollReveal>
            ))}
          </div>
        </ParallaxScroll>
      </div>
    </section>
  )
}
