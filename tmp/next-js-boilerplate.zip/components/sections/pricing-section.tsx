"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import { motion } from "framer-motion"

export function PricingSection() {
  const plans = [
    {
      name: "Mensal",
      description: "Perfeito para começar",
      price: "R$ 147",
      duration: "por mês",
      features: [
        "Acesso ao Cérebro Viral",
        "Todos os frameworks básicos",
        "Suporte normal",
        "Exportar em todos os formatos",
      ],
      cta: "Começar",
      popular: false,
      link: "https://go.perfectpay.com.br/PPU38CQ308M",
    },
    {
      name: "Trimestral",
      description: "Melhor custo-benefício",
      price: "R$ 247",
      duration: "à cada 3 meses",
      features: [
        "Acesso completo ao Cérebro Viral",
        "Todos os frameworks básicos e avançados",
        "Suporte prioritário",
        "Curso completo de Marketing Digital",
        "Marketplace de produtos para começar",
        "Relatórios de performance",
      ],
      cta: "Começar",
      popular: true,
      link: "https://go.perfectpay.com.br/PPU38CQ3JIR",
    },
  ]

  return (
    <section id="pricing" className="w-full py-12 md:py-24 lg:py-32">
      <div className="container px-4 md:px-6">
        <ScrollReveal>
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-heading font-bold tracking-tighter sm:text-5xl">
                Planos Simples e Transparentes
              </h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed dark:text-gray-400 opacity-70">
                Deixe a IA pensar como um criativo milionário. Escolha seu plano e comece a viralizar.
              </p>
            </div>
          </div>
        </ScrollReveal>

        <div className="mx-auto grid max-w-4xl grid-cols-1 gap-6 py-12 md:grid-cols-2">
          {plans.map((plan, index) => (
            <ScrollReveal key={index} delay={index * 0.1}>
              <div className="relative">
                {plan.popular && (
                  <div className="absolute -top-3 -right-3 px-4 py-1 bg-gradient-to-r from-purple-600 to-purple-500 text-white text-xs font-bold rounded-full z-10">
                    Mais Popular
                  </div>
                )}
                <Card
                  className={`h-full flex flex-col border-2 transition-all ${
                    plan.popular
                      ? "border-purple-600 bg-gradient-to-br from-slate-950 to-slate-900"
                      : "border-purple-500/50 bg-slate-900/50"
                  }`}
                >
                  <CardHeader>
                    <CardTitle className="text-xl tracking-tight">{plan.name}</CardTitle>
                    <div className="mt-4">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-muted-foreground ml-2 text-sm opacity-70">{plan.duration}</span>
                    </div>
                    <CardDescription className="mt-2 opacity-70">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col">
                    <ul className="space-y-3 mb-8 flex-1">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start">
                          <Check className="h-5 w-5 text-purple-500 mr-3 flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                      <Button
                        asChild
                        className={`w-full font-semibold py-2 ${
                          plan.popular
                            ? "bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-700 hover:to-purple-600 text-white border-0"
                            : "bg-transparent border-2 border-purple-600 text-white hover:bg-purple-600/10"
                        }`}
                      >
                        <a href={plan.link} target="_blank" rel="noopener noreferrer">
                          {plan.cta}
                        </a>
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  )
}
