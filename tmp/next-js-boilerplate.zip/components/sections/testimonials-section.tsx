"use client"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { AnimatedText } from "@/components/ui/animated-text"
import { motion } from "framer-motion"
import { AnimatedBackground } from "@/components/ui/animated-background"

export function TestimonialsSection() {
  const testimonials = [
    {
      name: "Alex Johnson",
      role: "Frontend Developer",
      content:
        "This component library has saved me countless hours of development time. The components are beautifully designed and easy to customize.",
      avatar: "AJ",
    },
    {
      name: "Sarah Chen",
      role: "UI/UX Designer",
      content:
        "As a designer, I appreciate the attention to detail in these components. They're not only functional but also aesthetically pleasing.",
      avatar: "SC",
    },
    {
      name: "Michael Rodriguez",
      role: "Product Manager",
      content:
        "Our team's productivity has increased significantly since we started using this library. The documentation is excellent and the components are robust.",
      avatar: "MR",
    },
  ]

  return (
    null
  )
}
