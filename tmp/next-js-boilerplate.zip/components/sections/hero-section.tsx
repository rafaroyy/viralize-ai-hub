"use client"

import { motion } from "framer-motion"
import Link from "next/link"
import { ArrowRight, PlayCircle } from "lucide-react"
import { useState } from "react"

import { SpotlightCard } from "@/components/ui/spotlight-card"
import { ScrollReveal } from "@/components/scroll-reveal"
import { MagneticButton } from "@/components/ui/magnetic-button"
import { AnimatedBackground } from "@/components/ui/animated-background"
import { GradientButton } from "@/components/ui-library/buttons/gradient-button"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2,
      delayChildren: 0.3,
    },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] },
  },
}

export function HeroSection() {
  const [showExclusiveModal, setShowExclusiveModal] = useState(false)

  const handleStartNow = () => {
    setShowExclusiveModal(true)
  }

  return (
    <section id="home" className="relative w-full py-12 md:py-24 lg:py-32 xl:py-48 overflow-hidden">
      <AnimatedBackground
        variant="gradient"
        color="rgba(168, 85, 247, 0.08)"
        secondaryColor="rgba(59, 130, 246, 0.08)"
      />

      <div className="container px-6 md:px-8">
        <div className="grid gap-8 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
          <ScrollReveal>
            <motion.div
              className="flex flex-col justify-center space-y-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.div className="space-y-4" variants={itemVariants}>
                <h1 className="text-4xl font-heading font-bold tracking-tighter sm:text-5xl xl:text-7xl/none">
                  <span className="gradient-text">O Cérebro Por Trás,</span>
                  <br />
                  <span className="text-foreground">Dos Vídeos Que Viralizam</span>
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400 opacity-70">
                  A IA que carrega os frameworks responsáveis por +500 milhões de impressões orgânicas no TikTok e
                  Instagram. Crie vídeos virais baseados em frameworks reais de venda.
                </p>
              </motion.div>

              <motion.div className="flex flex-col gap-6 sm:flex-row sm:items-center" variants={itemVariants}>
                <GradientButton
                  glowAmount={5}
                  className="px-6 py-2.5 text-base"
                  gradientFrom="from-purple-500"
                  gradientTo="to-blue-600"
                  onClick={handleStartNow}
                >
                  <span className="flex items-center">
                    Começar agora
                    <motion.span
                      className="ml-2 inline-block"
                      animate={{ x: [0, 4, 0] }}
                      transition={{ repeat: Number.POSITIVE_INFINITY, repeatDelay: 2, duration: 1 }}
                    >
                      <ArrowRight className="h-4 w-4" />
                    </motion.span>
                  </span>
                </GradientButton>

                <MagneticButton className="neumorphic-button">
                  <Link href="#how-it-works" className="px-6 py-2.5 block flex items-center gap-2">
                    <PlayCircle className="h-4 w-4" />
                    Ver Como Funciona
                  </Link>
                </MagneticButton>
              </motion.div>

              <motion.div variants={itemVariants} className="pt-4 flex gap-6">
                <div className="flex flex-col">
                  <p className="text-sm font-semibold text-foreground">+500M</p>
                  <p className="text-xs text-muted-foreground">Views Orgânicos</p>
                </div>
                <div className="flex flex-col">
                  <p className="text-sm font-semibold text-foreground">3.5X</p>
                  <p className="text-xs text-muted-foreground">Mais Engajamento</p>
                </div>
                <div className="flex flex-col">
                  <p className="text-sm font-semibold text-foreground">95%</p>
                  <p className="text-xs text-muted-foreground">Taxa de Viralização</p>
                </div>
              </motion.div>
            </motion.div>
          </ScrollReveal>

          <ScrollReveal delay={0.3}>
            <SpotlightCard className="relative h-[450px] w-full overflow-hidden rounded-xl border glassmorphic-card p-1 border-glow-blue">
              <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-transparent to-blue-900/20 z-10"></div>
              <div className="relative z-20 h-full w-full rounded-xl bg-gradient-to-br from-purple-950/50 to-blue-950/50 p-6 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-6 w-full max-w-md">
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.6 }}
                    className="col-span-2 h-24 rounded-xl bg-purple-800/20 border border-purple-800/30 flex items-center justify-center glassmorphic-inner-card"
                    whileHover={{ scale: 1.03, boxShadow: "0 0 15px rgba(168, 85, 247, 0.3)" }}
                  >
                    <span className="font-heading text-xl text-white tracking-tight text-center">
                      Frameworks de Viralização
                    </span>
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.8 }}
                    className="h-32 rounded-xl bg-blue-800/20 border border-blue-800/30 flex items-center justify-center glassmorphic-inner-card"
                    whileHover={{ scale: 1.03, boxShadow: "0 0 15px rgba(59, 130, 246, 0.3)" }}
                  >
                    <span className="font-heading text-white tracking-tight">AI</span>
                  </motion.div>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 1.0 }}
                    className="h-32 rounded-xl bg-purple-900/20 border border-purple-900/30 flex items-center justify-center glassmorphic-inner-card"
                    whileHover={{ scale: 1.03, boxShadow: "0 0 15px rgba(168, 85, 247, 0.3)" }}
                  >
                    <span className="font-heading text-white tracking-tight">Vídeos</span>
                  </motion.div>
                </div>
              </div>
            </SpotlightCard>
          </ScrollReveal>
        </div>
      </div>

      <Dialog open={showExclusiveModal} onOpenChange={setShowExclusiveModal}>
        <DialogContent className="sm:max-w-md bg-gradient-to-br from-slate-950 to-slate-900 border-2 border-purple-600">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center gradient-text">Acesso Exclusivo</DialogTitle>
            <DialogDescription className="text-center text-gray-300 mt-4 space-y-3">
              <div className="text-base">
                A <span className="font-semibold text-purple-400">Viralize AI</span> é uma ferramenta{" "}
                <span className="font-semibold text-purple-400">exclusiva para membros e convidados</span>.
              </div>
              <div className="text-sm text-gray-400">
                Nossa plataforma não está aberta ao público geral. Para ter acesso, você precisa ser convidado por um
                membro existente ou se tornar um membro oficial.
              </div>
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </section>
  )
}
