import Link from "next/link"
import { Icons } from "@/components/icons"
import { ScrollToTopButton } from "@/components/scroll-to-top-button"

export function SiteFooter() {
  return (
    <section className="border-t bg-background/80 backdrop-blur-lg" role="contentinfo">
      <div className="container flex flex-col gap-10 py-16">
        <div className="flex flex-col gap-10 md:flex-row">
          <div className="flex flex-1 flex-col gap-4">
            <Link href="/" className="flex items-center gap-2">
              <Icons.logo className="h-6 w-6" />
              <span className="font-heading text-xl tracking-tight">Viralize AI</span>
            </Link>
            <p className="text-sm text-muted-foreground opacity-70 max-w-xs">
              A IA que carrega os frameworks responsáveis por +500 milhões de impressões orgânicas.
            </p>
            <div className="flex gap-4">
              <Link href="https://instagram.com" target="_blank" rel="noreferrer" className="glassmorphic-icon">
                <Icons.instagram className="h-5 w-5 text-muted-foreground transition-colors hover:text-foreground" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="https://twitter.com" target="_blank" rel="noreferrer" className="glassmorphic-icon">
                <Icons.twitter className="h-5 w-5 text-muted-foreground transition-colors hover:text-foreground" />
                <span className="sr-only">Twitter</span>
              </Link>
              <Link href="https://youtube.com" target="_blank" rel="noreferrer" className="glassmorphic-icon">
                <Icons.youtube className="h-5 w-5 text-muted-foreground transition-colors hover:text-foreground" />
                <span className="sr-only">YouTube</span>
              </Link>
            </div>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-10 sm:grid-cols-3">
            <div className="flex flex-col gap-2">
              <h3 className="text-sm font-medium tracking-tight">Produto</h3>
              <ul className="flex flex-col gap-2">
                <li>
                  <Link
                    href="#features"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Recursos
                  </Link>
                </li>
                <li>
                  <Link
                    href="#pricing"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Preços
                  </Link>
                </li>
                <li>
                  <Link
                    href="#workflow"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Como Funciona
                  </Link>
                </li>
                <li>
                  <Link
                    href="#faq"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    FAQ
                  </Link>
                </li>
              </ul>
            </div>
            <div className="flex flex-col gap-2">
              <h3 className="text-sm font-medium tracking-tight">Empresa</h3>
              <ul className="flex flex-col gap-2">
                <li>
                  <Link
                    href="#sobre"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Sobre
                  </Link>
                </li>
                <li>
                  <Link
                    href="#blog"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Blog
                  </Link>
                </li>
                <li>
                  <Link
                    href="#casos"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Casos de Sucesso
                  </Link>
                </li>
                <li>
                  <Link
                    href="#contato"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Contato
                  </Link>
                </li>
              </ul>
            </div>
            <div className="flex flex-col gap-2">
              <h3 className="text-sm font-medium tracking-tight">Legal</h3>
              <ul className="flex flex-col gap-2">
                <li>
                  <Link
                    href="#privacidade"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Privacidade
                  </Link>
                </li>
                <li>
                  <Link
                    href="#termos"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Termos de Uso
                  </Link>
                </li>
                <li>
                  <Link
                    href="#cookies"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Cookies
                  </Link>
                </li>
                <li>
                  <Link
                    href="#licencas"
                    className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
                  >
                    Licenças
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <p className="text-sm text-muted-foreground opacity-70">
            &copy; {new Date().getFullYear()} Viralize AI. Todos os direitos reservados.
          </p>
          <div className="flex gap-4">
            <Link
              href="#termos"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
            >
              Termos
            </Link>
            <Link
              href="#privacidade"
              className="text-sm text-muted-foreground transition-colors hover:text-foreground opacity-70"
            >
              Privacidade
            </Link>
          </div>
        </div>
      </div>
      <ScrollToTopButton />
    </section>
  )
}
