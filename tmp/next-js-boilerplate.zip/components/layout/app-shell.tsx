"use client"

import type React from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { LogOut, Video, History } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { authApi } from "@/lib/api-client"

interface AppShellProps {
  children: React.ReactNode
  username: string
  currentView: "editor" | "history"
  onViewChange: (view: "editor" | "history") => void
}

export function AppShell({ children, username, currentView, onViewChange }: AppShellProps) {
  const router = useRouter()

  const handleLogout = () => {
    authApi.logout()
    router.push("/login")
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="h-16 border-b border-border bg-card/80 backdrop-blur-md sticky top-0 z-50">
        <div className="h-full px-6 flex items-center justify-between">
          {/* Logo e Brand */}
          <div className="flex items-center gap-3">
            <Image src="/viralize-ai-logo.png" alt="Viralize AI" width={44} height={44} className="rounded" />
            <div>
              <h1 className="text-lg font-heading font-bold gradient-text">Viralize AI</h1>
              <p className="text-xs text-muted-foreground">Studio Premium</p>
            </div>
          </div>

          {/* Navigation & User */}
          <div className="flex items-center gap-4">
            {/* Navigation Buttons */}
            <div className="flex items-center gap-2">
              <Button
                variant={currentView === "editor" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange("editor")}
                className="gap-2"
              >
                <Video className="h-4 w-4" />
                Editor
              </Button>
              <Button
                variant={currentView === "history" ? "default" : "ghost"}
                size="sm"
                onClick={() => onViewChange("history")}
                className="gap-2"
              >
                <History className="h-4 w-4" />
                Histórico
              </Button>
            </div>

            {/* User Badge */}
            <Badge variant="secondary" className="px-3 py-1.5">
              {username}
            </Badge>

            {/* Logout Button */}
            <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-2">
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 min-h-0">{children}</main>
    </div>
  )
}
