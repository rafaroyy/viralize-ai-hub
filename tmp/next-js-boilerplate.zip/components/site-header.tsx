"use client"

import * as React from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import { List, X } from "lucide-react"
import Image from "next/image"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { useScrollPosition } from "@/hooks/use-scroll-position"

const navItems = [
  { name: "Início", href: "#home" },
  { name: "Como Funciona", href: "#how-it-works" },
  { name: "Frameworks", href: "#frameworks" },
  { name: "Blog", href: "#blog" },
]

export function SiteHeader() {
  const pathname = usePathname()
  const scrollPosition = useScrollPosition()
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false)
  const [showExclusiveModal, setShowExclusiveModal] = React.useState(false)

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  const closeMobileMenu = () => {
    setMobileMenuOpen(false)
  }

  const handleStartNow = () => {
    setShowExclusiveModal(true)
    closeMobileMenu()
  }

  return (
    <header
      className={cn(
        "fixed top-0 z-50 w-full transition-all duration-300",
        scrollPosition > 10 ? "bg-background/80 backdrop-blur-lg border-b border-border/40" : "bg-transparent",
      )}
    >
      <div className="container px-4 md:px-6 flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center space-x-2 z-10">
          <Image
            src="/viralize-ai-logo.png"
            alt="Viralize AI"
            width={144}
            height={144}
            className="rounded-md leading-7 mx-0"
          />
        </Link>

        <nav className="hidden md:flex items-center space-x-1 lg:space-x-6">
          {navItems.map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors relative group"
              onClick={(e) => {
                e.preventDefault()
                document.querySelector(item.href)?.scrollIntoView({
                  behavior: "smooth",
                })
              }}
            >
              {item.name}
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-primary scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-200"></span>
            </Link>
          ))}
        </nav>

        <div className="flex items-center space-x-4">
          <ModeToggle />

          <div className="hidden md:flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="neumorphic-button" asChild>
              <Link href="/login">Entrar</Link>
            </Button>
            <Button size="sm" className="neumorphic-button-primary" onClick={handleStartNow}>
              Começar agora
              <motion.div
                className="ml-1"
                animate={{ x: [0, 3, 0] }}
                transition={{ repeat: Number.POSITIVE_INFINITY, repeatDelay: 3, duration: 0.8 }}
              >
                →
              </motion.div>
            </Button>
          </div>

          <button
            className="md:hidden flex items-center justify-center p-2 rounded-md bg-background/90 border border-border/40 shadow-sm"
            onClick={toggleMobileMenu}
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="text-foreground h-5 w-5" /> : <List className="text-foreground h-5 w-5" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            className="fixed inset-0 z-40 bg-background/50 backdrop-blur-sm md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="fixed inset-y-0 right-0 z-50 w-full max-w-xs bg-background shadow-xl border-l border-border"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
            >
              <div className="flex items-center justify-between p-4 border-b border-border">
                <Link href="/" className="flex items-center space-x-2" onClick={closeMobileMenu}>
                  <Image
                    src="/viralize-ai-logo.png"
                    alt="Viralize AI"
                    width={120}
                    height={120}
                    className="rounded-md"
                  />
                  <span className="font-heading text-lg">Viralize AI</span>
                </Link>
                <button
                  onClick={closeMobileMenu}
                  className="p-2 rounded-full hover:bg-muted transition-colors"
                  aria-label="Close menu"
                >
                  <X className="text-foreground h-5 w-5" />
                </button>
              </div>

              <div className="py-4 px-2">
                <nav className="flex flex-col space-y-1">
                  {navItems.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="px-4 py-3 text-base font-medium text-foreground hover:bg-muted rounded-md transition-colors"
                      onClick={(e) => {
                        e.preventDefault()
                        document.querySelector(item.href)?.scrollIntoView({
                          behavior: "smooth",
                        })
                        closeMobileMenu()
                      }}
                    >
                      {item.name}
                    </Link>
                  ))}
                </nav>
              </div>

              <div className="mt-auto p-4 border-t border-border">
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="w-full bg-transparent" asChild>
                    <Link href="/login" onClick={closeMobileMenu}>
                      Entrar
                    </Link>
                  </Button>
                  <Button className="w-full neumorphic-button-primary" onClick={handleStartNow}>
                    Começar agora
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Dialog open={showExclusiveModal} onOpenChange={setShowExclusiveModal}>
        <DialogContent className="sm:max-w-md bg-gradient-to-br from-slate-950 to-slate-900 border-2 border-purple-600">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center gradient-text">Acesso Exclusivo</DialogTitle>
            <DialogDescription className="text-center text-gray-300 mt-4 space-y-3">
              <div className="text-base">
                A <span className="font-semibold text-purple-400">Viralize AI</span> é uma ferramenta{" "}
                <span className="font-semibold text-purple-400">exclusiva para membros e convidados</span>.
              </div>
              <div className="text-sm text-gray-400">
                Nossa plataforma não está aberta ao público geral. Para ter acesso, você precisa ser convidado por um
                membro existente ou se tornar um membro oficial.
              </div>
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </header>
  )
}
